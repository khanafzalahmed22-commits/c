#ifndef INCLUDE_MBR_CLNT_UNDRLNG_FILE
#define INCLUDE_MBR_CLNT_UNDRLNG_FILE

#include <Logger.h>
#include <MAX_LEN.h>

class MbrClntUndrLng
{
	public:
		MbrClntUndrLng(Logger* logger);
		int readFileInsertIntoDataBase(char* );
		int sql_stmt;

	private:
		Logger *Objlogger;
		int sqlToInsertData();		
};
#endif
