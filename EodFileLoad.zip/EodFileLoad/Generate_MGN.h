/***************************************************************************
* FILE NAME		:	Generate_PSN.h
*
* CREATION DATE	:	28-JUL-2005
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Sonia Joshi
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.		<MM-DD-YYYY>		Changed so and so
*
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>

#ifndef GENERATE_MGN
#define GENERATE_MGN

#define FIL_NM_LEN 	18
#define IP_LEN		16
#define	USER_LEN	15
#define	PASS_LEN	15
#define	FILE_PATH_LEN	120
using namespace std;

class Generate_MGN	
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[FIL_NM_LEN];
		char*	server_ip ;
		char*	user ;
		char*	password ;
		char*	file_path ;
		char* 	repository_path ;
		char*	port ;						//CR06359: Arushi added

		FILE	*seq_fp;
		int		recs_printed ;
		int		Generate_MGN_file();
		int		open_file();
		int		declare_print_contracts();
		int 	RecordsAdded;
		int		Create_Control();
		int		MoveFile();
		int		FtpFile();

		//CR06612 :Rahul Start
		char*	ncfe_server_ip ;
		char*	ncfe_user ;
		char*	ncfe_password ;
		char*	ncfe_port ;
		char* 	ncfe_dest_file_path ;
		char*	mge_file_path ;
		int		NCFE_FtpFile();
		//CR06612 :Rahul End
		char*   ncfe_ftp_flag;                 // CR06830 Vinod Added

		// CR06787: Annapoorna: Added: Start
		char	seq_fname_nccl[FIL_NM_LEN];
		FILE	*seq_fp_nccl;
		int		recs_printed_nccl;
		int		open_file_nccl();
		int		Create_Control_NCCL();
		int		declare_print_contracts_nccl();
		// CR06787: Annapoorna: Added: End

	public:

		Generate_MGN(Logger *Log)
		{
			RecordsAdded	=	0;
			Objlogger		=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip=NULL ;
			user=NULL ;
			password=NULL ;
			file_path=NULL ;
			repository_path=NULL ;
			port=NULL ;										//CR06359: Arushi added
			memset( seq_fname, '\0',FIL_NM_LEN );
			strcpy( seq_fname,"NCDEX");
			//CR06612 : Rahul start
			ncfe_server_ip=NULL;
			ncfe_user=NULL;
			ncfe_password=NULL;
			ncfe_port=NULL;
			ncfe_dest_file_path=NULL;
			mge_file_path=NULL;
			//CR06612 : Rahul End
			ncfe_ftp_flag=NULL;                   //CR06830 Vinod Added

			// CR06787: Annapoorna: Added: Start
			memset( seq_fname_nccl, '\0',FIL_NM_LEN );
			recs_printed_nccl = 0;
			// CR06787: Annapoorna: Added: End
			
		};

		~Generate_MGN()
		{
			delete ObjconfigurationFileManager;
			delete server_ip ;
			delete user ;
			delete password ;
			delete file_path ;
			delete repository_path ;
			delete port ;									//CR06359: Arushi added
			//CR06612 : Rahul Start
			delete ncfe_server_ip;
			delete ncfe_user;
			delete ncfe_password;
			delete ncfe_port;
			delete ncfe_dest_file_path;
			delete mge_file_path;
			//CR06612 : Rahul End
			delete ncfe_ftp_flag;               //CR06830 Vinod Added
		};

		int  CreateFile(char*,char*,char*);
		int Init(char *);
	
};
#endif
