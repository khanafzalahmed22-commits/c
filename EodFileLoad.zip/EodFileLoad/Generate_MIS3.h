/***************************************************************************
* FILE NAME	:	Generate_MIS3.h
*
* CREATION DATE	:	07-MAR-11	
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Rachna	
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.	CR02128	17-OCT-2012			Changes for copying file to NAS Folder	Anesh Mishra
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>

#ifndef GENERATE_MIS3
#define GENERATE_MIS3

using namespace std;

#define MIS3_FILE_NM_LEN 	50	
#define IP_LEN		16
#define	USER_LEN	15
#define	PASS_LEN	15
#define	FILE_PATH_LEN	120

class Generate_MIS3
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[MIS3_FILE_NM_LEN];
		char*	server_ip ;
		char*	user ;
		char*	password ;
		char*	file_path ;
		char* 	repository_path ;
		char*	port ;				//CR06359: Arushi added
		char*   Nas_file_path ; // CR02128

		FILE	*seq_fp;
		int	recs_printed ;
		int	Generate_MIS3_file();
		int	open_file();
		int	declare_print_contracts();
		int 	RecordsAdded;
		int	Create_Control();
		int	MoveFile();
		int	FtpFile();
		int     CopyToNas();//CR CR02128 Function to copy the generated file to NAs folder With changed name 
	public:

		Generate_MIS3(Logger *Log)
		{
			RecordsAdded	=	0;
			Objlogger	=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip=NULL ;
			user=NULL ;
			password=NULL ;
			file_path=NULL ;
			repository_path=NULL ;
			port=NULL ;										//CR06359: Arushi added
			memset( seq_fname, '\0',MIS3_FILE_NM_LEN);
		};

		~Generate_MIS3()
		{
			delete ObjconfigurationFileManager;
			delete server_ip ;
			delete user ;
			delete password ;
			delete file_path ;
			delete repository_path ;
			delete port ;						//CR06359: Arushi added
		};

		int  CreateFile(char*);
		int Init(char *);
	
};
#endif
