#ifndef INCLUDE_USR_CLNT_MSTR
#define INCLUDE_USR_CLNT_MSTR
#include <Logger.h>

class UsrClnt
{
 public:
    UsrClnt(Logger *logger );
	int readFileInsertIntoDataBase(char* UsrClntFile);
    int sql_stmt;
 private:
    Logger *Objlogger;
};
#endif
