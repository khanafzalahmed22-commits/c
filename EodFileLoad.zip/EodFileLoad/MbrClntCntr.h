#ifndef INCLUDE_CLNT_CNTR_FILE
#define INCLUDE_CLNT_CNTR_FILE
#include <Logger.h>

#include<MAX_LEN.h>

struct StClntrCntr;

class MbrClntCntr
{
	public:
		MbrClntCntr(Logger* logger);
		int readFileInsertIntoDataBase(char*);
		int sql_stmt;
	private:
        int RecsInstrtd;
        int RecsUpdated;
	Logger *Objlogger;
};
#endif
