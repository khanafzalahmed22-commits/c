/***************************************************************************
* FILE NAME		:	Generate_MG13.h
*
* CREATION DATE	:	28-JUL-2005
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Sonia Joshi
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.		<MM-DD-YYYY>		Changed so and so
*
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include "Generate_MG12.h"

#ifndef GENERATE_MG13
#define GENERATE_MG13

#define FIL_NM_LEN 	18
#define IP_LEN		16
#define	USER_LEN	15
#define	PASS_LEN	15
#define	FILE_PATH_LEN	120
using namespace std;

class Generate_MG13
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[MAX_FILE_NAME];
		string	server_ip ;
		string	user ;
		string	password ;
		string	file_path ;
		string 	repository_path ;
		string  port ; 						//CR06359 : Arushi added
		string  mode ;                      //CR06713: Neha added


		FILE	*seq_fp;
		int		recs_printed ;
		int		Generate_MG13_file();
		int		open_file();
		int		declare_print_contracts();
		int 	RecordsAdded;
		int		MoveFile();
		int		FtpFile();
		vector<string>vszFileNames;
		int     m_iNodeNo ;
		
	public:

		Generate_MG13(Logger *Log)
		{
			RecordsAdded	=	0;
			Objlogger		=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip.clear() ;
			user.clear() ;
			password.clear() ;
			file_path.clear() ;
			repository_path.clear() ;
			port.clear() ; 											//CR06359: Arushi added
			mode.clear() ;                                         //CR06713: Neha added
			memset( seq_fname, '\0', MAX_FILE_NAME );
			strcpy( seq_fname,"NCDEX");
		};

		~Generate_MG13()
		{
			delete ObjconfigurationFileManager;
		};

		int CreateFile(char*);
		int Init(char *);
	
};
#endif
