#ifndef INCLUDE_UNDR_LNG_MST
#define INCLUDE_UNDR_LNG_MST

#include <Logger.h>
#include <Struct_UndrLngMst.h>

class 	UndrLngMst
{
 public:
    UndrLngMst(Logger *logger);
    int sql_stmt;
	int	readFileInsertIntoDataBase(char* UndrLngFile);
 private:
    Logger *Objlogger;
};
#endif
