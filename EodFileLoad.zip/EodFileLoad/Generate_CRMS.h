/***************************************************************************
* FILE NAME		:	Generate_CRMS..h
*
* CREATION DATE	:	18-AUG-2011
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Abhijeet Srivastava
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.		<MM-DD-YYYY>		Changed so and so
*
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>



#ifndef GENERATE_CRMS
#define GENERATE_CRMS

#define FIL_NM_LEN 	18
#define IP_LEN		16
#define	USER_LEN	15
#define	PASS_LEN	15
#define	FILE_PATH_LEN	120
using namespace std;

int Dos2UnixCmd(const char* inputFileFullPath); //CR06732: Annapoorna: Added

class Generate_CRMS
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[FIL_NM_LEN];
		char*	server_ip ;
		char*	user ;
		char*	password ;
		char*	file_path ;
		char* 	repository_path ;
		bool    CRMSFileFound;
		
		FILE	*seq_fp;
		int		recs_printed ;
		int		Generate_CRMS_file();
		int		open_file();
		int		declare_print_contracts();
		int 	RecordsAdded;
		int		Create_Control();
		int		MoveFile();
		int		FtpFile();
		int     Check_CRMS_file();
		
		
	public:

		Generate_CRMS(Logger *Log)
		{
			RecordsAdded	=	0;
			Objlogger		=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip=NULL ;
			user=NULL ;
			password=NULL ;
			file_path=NULL ;
			repository_path=NULL ;
			CRMSFileFound = false;
			
			memset( seq_fname, '\0',FIL_NM_LEN );
			strcpy( seq_fname,"NCDEX");
		};

		~Generate_CRMS()
		{
			delete ObjconfigurationFileManager;
			delete server_ip ;
			delete user ;
			delete password ;
			delete file_path ;
			delete repository_path ;
		};

		int  CreateFile(char*,char*);
		int Init(char *);
		int	ReadCRMSEodFileUpdateToDataBase();//Saransh - CRMS_EOD file processing
		int	ClientEDUpdateforTM();//Bharat - CR06776
		int	MemberEDUpdateforCM();//Bharat - CR06776

	
};
#endif
