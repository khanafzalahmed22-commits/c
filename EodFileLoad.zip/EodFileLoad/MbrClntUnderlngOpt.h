#ifndef INCLUDE_MBR_CLNT_UNDERLNG_OPT_FILE
#define INCLUDE_MBR_CLNT_UNDERLNG_OPT_FILE

#include <Logger.h>
#include <MAX_LEN.h>

class MbrClntUnderlngOpt
{
	public:
		MbrClntUnderlngOpt(Logger* logger);
		int readFileInsertIntoDataBase(char* );
		int sql_stmt;

	private:
		Logger *Objlogger;
		int sqlToInsertData(); //sumaiya-?
};
#endif
