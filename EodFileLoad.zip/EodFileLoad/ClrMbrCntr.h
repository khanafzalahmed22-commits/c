#ifndef INCLUDE_CLR_MBR_CNTR
#define INCLUDE_CLR_MBR_CNTR
#include <Logger.h>

class ClrMbrCntr
{

public:
    ClrMbrCntr(Logger *logger );
	int readFileInsertIntoDataBase(char* ClrMbrCtrDataFile);
    int sql_stmt;

private:
	int sqlToInsertData();
	void initInsertArray();
	int insertArray(struct StClrMbrCntr& );

    Logger *Objlogger;
};
#endif
