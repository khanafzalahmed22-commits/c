#ifndef INCLUDE_Mrgn_VLTN
#define INCLUDE_Mrgn_VLTN

#include <Logger.h>
class Mrgn_VLTN
{
public:
    Mrgn_VLTN(Logger *logger);
    int sql_stmt;
	int readFileInsertIntoDataBase(char*);

private:
    Logger *Objlogger;
	int RecsInstrtd;
	int RecsUpdated;
	int alrt_id;
};
#endif
