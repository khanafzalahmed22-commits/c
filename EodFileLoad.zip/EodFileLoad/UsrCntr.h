#ifndef INCLUDE_USR_CNTR_MSTR
#define INCLUDE_USR_CNTR_MSTR

#include <Logger.h>
class UsrCntrMstr
{
public:
    UsrCntrMstr(Logger *logger );
	int readFileInsertIntoDataBase(char*);
    int sql_stmt;
private:
    Logger *Objlogger;
};
#endif
