#include <Logger.h>
#include <OPMS_DEF.h>
#include <MAX_LEN.h>
#include <fstream>
#include <ConfigurationFileManager.h>
#include <vector>
#include "DEF.h"

#ifndef  ASN_LOADER
#define ASN_LOADER

class ASN_Loader
{
private :
	 Logger *Objlogger;
	 char BtchDate[MAX_DATE_LEN + 1];	 
public :
	ASN_Loader( Logger *Objlog);
	char current_date[MAX_DATE_LEN + 1];
	int populatedevolvementdetails();	
	int PopulateDevolveInUsrClntCntr();
	int PopulateInUsrClntCntr();	 
	int PopulateMbrClntCntr();
	int PopulateMbrCntr();
	int PopulateMbrClntUndelying();
	int PopulateMbrUndelying();
	int PopulateMbrClntCommodity();
	int PopulateMbrClntNMCommodity();
	int PopulateMbrCommodity();
	int PopulateMbrNMCommodity();	 
	int Populate_DEVOLVE_MBR_CLNT_CNTR();	int CashSettleASNDetails();
	~ASN_Loader();
};
#endif
