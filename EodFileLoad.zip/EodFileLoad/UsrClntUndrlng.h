#ifndef INCLUDE_USR_CLNT_UNDRLNG
#define INCLUDE_USR_CLNT_UNDRLNG

#include <Logger.h>
class UsrClntUndrlng
{
 public:
    UsrClntUndrlng(Logger *logger );
	int readFileInsertIntoDataBase(char* UsrClntUndrlngFile);
    int sql_stmt;
 private:
    Logger *Objlogger;
};
#endif
