/***************************************************************************
* FILE NAME		:	MbrUndrLng.h 
*
* CREATION DATE	:	30-DEC-2004
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Suresh k.
*
* DESCRIPTION	:
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details     Remarks
* 1.
***************************************************************************/

#ifndef INCLUDE_MBR_UNDR_LNG
#define INCLUDE_MBR_UNDR_LNG

#include <Logger.h>
class MbrUndrLng
{
	public:
		MbrUndrLng(Logger *logger );
		int readFileInsertIntoDataBase(char* );
		int sql_stmt;

	private:
		Logger *Objlogger;
};
#endif



/****************************end of the program******************************/
