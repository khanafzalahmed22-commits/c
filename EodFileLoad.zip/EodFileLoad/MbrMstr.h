#ifndef INCLUDE_MBR_MSTR
#define INCLUDE_MBR_MSTR

#include <Logger.h>
#include <OPMS_DEF.h>
#include <sqlca.h>
#include <MAX_LEN.h>
#include <Struct_Mbr_Mstr.h>

class MbrMstr
{
public:
    MbrMstr(Logger *logger );
    int sql_stmt;
	virtual	int readFileInsertIntoDataBase(char*);
private:
    Logger *Objlogger;
};
#endif
