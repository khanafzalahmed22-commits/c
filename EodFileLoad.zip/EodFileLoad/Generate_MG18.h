/***************************************************************************
* FILE NAME		:	Generate_MG18.h
*
* CREATION DATE	:	04-FEB-2020
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Arushi Agarwal
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.		<MM-DD-YYYY>		Changed so and so
*
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include <vector>

#ifndef GENERATE_MG18
#define GENERATE_MG18

#define MAX_STRING_LEN 	1001
#define MAX_CM_LEN		50
#define	PASS_LEN		15
#define	MAX_FILES		100

using namespace std;

class Generate_MG18
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[MAX_FILE_NAME];
		string	server_ip ;
		string	user ;
		string	password ;
		string	file_path ;
		string 	repository_path ;
		string  port ;						//CR06359:Arushi added
		string  mode ;                     //CR06713: Neha added

		FILE	*seq_fp;
		int		recs_printed ;
		int		Generate_MG18_file();
		int		open_file();
		int		declare_print_contracts();
		int 	RecordsAdded;
		int		MoveFile();
		int		FtpFile();
		vector<string>vszFileNames;
		int		m_iNodeNo ;
		
	public:

		Generate_MG18(Logger *Log)
		{
			vszFileNames.clear();
			RecordsAdded	=	0;
			Objlogger		=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip.clear() ;
			user.clear() ;
			password.clear() ;
			port.clear() ;								//CR06359:Arushi added
			mode.clear() ;                              //CR06713: Neha added
			file_path.clear() ;
			repository_path.clear() ;
			memset( seq_fname, '\0', MAX_FILE_NAME );
			strcpy( seq_fname,"NCDEX");
		};

		~Generate_MG18()
		{
			delete ObjconfigurationFileManager;
		};

		int  CreateFile(char*);
		int Init(char *);
	
};
#endif
