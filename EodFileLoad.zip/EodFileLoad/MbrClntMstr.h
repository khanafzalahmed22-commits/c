#ifndef INCLUDE_MBR_CLNT_MSTR
#define INCLUDE_MBR_CLNT_MSTR
#include <Struct_Mbr_Clnt_Mstr.h>
#include <Logger.h>
#include <MultiMapMngr.h>  

class MbrClntMstr
{
	public:
		MbrClntMstr(Logger *logger);
		int readFileInsertIntoDataBase(char*);
		int readFileInsertIntoDataBaseCutoff(char*); //CR06271 : Bhoopesh
		int readBMSFileInsertIntoDataBaseCutoff(char* ,char*); //CR06936 :Vinod:Added
	    int sql_stmt;

	private:
    	Logger *Objlogger;
		int	RecsInstrtd;
		int RecsUpdated;
		MultiMapMngr 	*ObjMbrClientMultiMapBMS;  //CR06936:Vinod:Added
};
#endif

