#ifndef INCLUDE_MBR_CNTR
#define INCLUDE_MBR_CNTR

#include <Logger.h>
class MbrCntr
{
 public:
    MbrCntr(Logger *logger );
	int readFileInsertIntoDataBase(char* MbrCtrDataFile);
    int sql_stmt;
 private:

    Logger *Objlogger;
};
#endif
