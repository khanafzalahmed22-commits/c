#ifndef INCLUDE_OI_VLTN
#define INCLUDE_OI_VLTN

#include <Logger.h>
class OI_VLTN
{
public:
    OI_VLTN(Logger *logger);
    int sql_stmt;
	int readFileInsertIntoDataBase(char*);

private:
    Logger *Objlogger;
	int RecsInstrtd;
	int RecsUpdated;
	int alrt_id;
};
#endif
