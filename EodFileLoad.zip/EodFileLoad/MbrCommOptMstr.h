/***************************************************************************
* FILE NAME		:  	MbrCommOptMstr.pc
*
* CREATION DATE	:	20-SEP-2017
*
* COPYRIGHTS	: 	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Sumaiya Ansari
*
* DESCRIPTION	:	Load the data for Member commodity Opt master from oracle table into respective file and back.
*
* MODIFICATION COMMENTS:
* ---------------------------------------------------------------------------------------
* Sr    CR. NO  Modification Date   Modification Details        Remarks
* 1.
******************************************************************************************/

#ifndef INCLUDE_MBR_COMM_OPT_MSTR
#define INCLUDE_MBR_COMM_OPT_MSTR
#include <Struct_Mbr_Comm_Opt_Mstr.h>
#include <Logger.h>

class MbrCommOptMstr
{
public:
    MbrCommOptMstr(Logger *logger );
    int sql_stmt;
    int readFileInsertIntoDataBase(char*);
private:
    Logger *Objlogger;

};
#endif
