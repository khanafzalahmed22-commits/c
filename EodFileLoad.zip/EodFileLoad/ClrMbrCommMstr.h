
// FILE NAME		:		ClrMbrCommMstr.h
// CREATION DATE	:		21-Apr-2014	
// COPYRIGHTS		:		Tata Consultancy Services, Mumbai
// DESCRIPTION		:		Loads data from OPM_MBR_COMMDTY table in database into respective file.
// CR No. 			:		CR02415
// CREATED BY 		:		Anil D 
// CREATION DATE	: 		21-Apr-2014 
// $Header: /home/riskcvs/rmscvsroot/RmsDev/SourceCode/OpmsFileGnrtn/MbrCommMstr.h
/* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details     			Remarks
* 1.   
*/
//--------------------------------------------------------------------------
//using namespace std;
#ifndef INCLUDE_CLR_MBR_COMDTYFILE
#define INCLUDE_CLR_MBR_COMDTYFILE
#include <Struct_Clr_Mbr_Comm_Mstr.h>
#include <MAX_LEN.h>
#include 	<Logger.h>

class ClrMbrCommMstr 
{
 public:
	ClrMbrCommMstr(Logger *logger);
	virtual int readFileInsertIntoDataBase(char*);
	int sql_stmt;		

 private:
		int RecsInstrtd;        
	Logger *Objlogger;

};
#endif //INCLUDE_CLR_MBR_COMDTY_FILE

