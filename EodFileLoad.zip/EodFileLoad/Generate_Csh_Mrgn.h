/***************************************************************************
* FILE NAME     :  	Generate_Csh_Mrgn.h
* CREATION DATE :   24-DEC-2010
* COPYRIGHTS    :   Tata Consultancy Services, Mumbai
* CREATED BY    :  	Krupa Shankar
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details     Remarks
* 1.   		     <MM-DD-YYYY>        Changed so and so
*
***************************************************************************/
#include <iostream>
#include <sqlca.h>
#include <MAX_LEN.h>
#include <OPMS_DEF.h>
#include <Logger.h>
#include <ConfigurationFileManager.h>


using namespace std;


class Generate_Csh_Mrgn 
{
    private:
        Logger  *logger;
		int generate_cm_client_level();		//! calculates cash margin at contract level
		int summation_cm_client_level();	//! sum up the cash margin at client level
		int summation_cm_cm_level();		//! sum up cash margin at clearing member level

    public:
		Generate_Csh_Mrgn(Logger *Log);
		~Generate_Csh_Mrgn();
		int populate_cm();					//! call this method from external system - calls the above methods.
};

