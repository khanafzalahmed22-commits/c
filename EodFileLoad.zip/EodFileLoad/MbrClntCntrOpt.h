#ifndef MBR_CLNT_CNTR_OPT_FILE
#define MBR_CLNT_CNTR_OPT_FILE
#include <Logger.h>

#include <MAX_LEN.h>


class MbrClntCntrOpt
{
	public:
		MbrClntCntrOpt(Logger* logger);
		int readFileInsertIntoDataBase(char*);
		int sql_stmt;
	private:
        int RecsInstrtd;
        int RecsUpdated;
	Logger *Objlogger;
};
#endif
