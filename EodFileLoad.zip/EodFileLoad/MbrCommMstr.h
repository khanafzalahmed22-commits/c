/***************************************************************************
* FILE NAME		:  	MbrCommMstr.pc
*
* CREATION DATE	:	16-MAY-2014
*
* COPYRIGHTS	: 	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Ananya Dutta
*
* DESCRIPTION	:	Load the data for Member commodity master from oracle table into respective file and back.
*
* MODIFICATION COMMENTS:
* ---------------------------------------------------------------------------------------
* Sr    CR. NO  Modification Date   Modification Details        Remarks
* 1.    CR02415 24-JUN-2014   Added code for commodity level.
******************************************************************************************/

#ifndef INCLUDE_MBR_COMM_MSTR
#define INCLUDE_MBR_COMM_MSTR
#include	<Struct_Mbr_Comm_Mstr.h>
#include 	<Logger.h>


class MbrCommMstr
{
public:
    MbrCommMstr(Logger *logger );
    int sql_stmt;
    int readFileInsertIntoDataBase(char*);
private:
    Logger *Objlogger;

};
#endif

