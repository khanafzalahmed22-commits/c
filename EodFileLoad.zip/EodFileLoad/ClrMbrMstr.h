#ifndef INCLUDE_CLR_MBR_MSTR
#define INCLUDE_CLR_MBR_MSTR
#include	<Struct_Clr_Mbr_Mstr.h>
#include 	<Logger.h>


class ClrMbrMstr
{
public:
    ClrMbrMstr(Logger *logger );
    int sql_stmt;
    int readFileInsertIntoDataBase(char*);
private:
    Logger *Objlogger;

};
#endif

