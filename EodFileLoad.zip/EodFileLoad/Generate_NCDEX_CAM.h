/***************************************************************************
* FILE NAME		:	Generate_NCDEX_CAM.h
*
* CREATION DATE	:	18-OCT-2011
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Krupa Shankar Sethuraman
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.
*
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h>
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include <vector>

#ifndef GENERATE_NCDEX_CAM
#define GENERATE_NCDEX_CAM

#define MAX_STRING_LEN 	1001
#define MAX_CM_LEN		50
#define	PASS_LEN		15
#define	MAX_FILES		100

using namespace std;

class Generate_NCDEX_CAM
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[MAX_FILE_NAME];
		string	server_ip ;
		string	user ;
		string	password ;
		string	file_path ;
		string 	repository_path ;
		string  port ;						//CR06359: Arushi added

		FILE	*seq_fp;
		int		recs_printed ;
		int		Generate_NCDEX_CAM_file(char*);
		int		open_file();
		int		CreateFileContent(char*);
		int 	RecordsAdded;
		int		MoveFile();
		int		FtpFile();
		vector<string>vszFileNames;
		int		m_iNodeNo ;

	public:
		int  CreateFile(char*);
		int Init(char*);
		
		Generate_NCDEX_CAM(Logger *Log)
		{
			vszFileNames.clear();
			RecordsAdded	=	0;
			Objlogger		=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip.clear() ;
			user.clear() ;
			password.clear() ;
			file_path.clear() ;
			repository_path.clear() ;
			port.clear() ;									//CR06359: Arushi added
			memset( seq_fname, '\0', MAX_FILE_NAME );
			strcpy( seq_fname,"NCDEX");

		}

		~Generate_NCDEX_CAM()
		{
			delete ObjconfigurationFileManager;
		}
};
#endif
