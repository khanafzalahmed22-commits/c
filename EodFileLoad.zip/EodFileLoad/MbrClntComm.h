/***************************************************************************
* FILE NAME		:	MbrClntComm.pc
*
* CREATION DATE	:	19-MAY-2014
*
* COPYRIGHTS	: 	Tata Consultancy Services, Mumbai
*
* CREATED BY	: 	Ananya Dutta
*
* DESCRIPTION	:	Load the data from oracle table into respective file.
*
* MODIFICATION COMMENTS:
* ---------------------------------------------------------------------------------------
* Sr    CR. NO  Modification Date   Modification Details        Remarks
* 1.    CR02415 24-JUN-2014   Added code for commodity level.
******************************************************************************************/

#ifndef INCLUDE_MBR_CLNT_COMDTY_FILE
#define INCLUDE_MBR_CLNT_COMDTY_FILE

#include <Logger.h>
#include <MAX_LEN.h>


class MbrClntComm
{
	public:
		MbrClntComm(Logger* logger); 
		int readFileInsertIntoDataBase(char* );
		int sql_stmt;

	private:
		Logger *Objlogger;
		int sqlToInsertData();		
};
#endif

