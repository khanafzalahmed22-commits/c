/***************************************************************************
* FILE NAME		:	Generate_New_CM_Mrgn.h
*
* CREATION DATE	:	20-DEC-2023
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Vinod Kumar
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.		<MM-DD-YYYY>		Changed so and so
*
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include "Generate_MG12.h"

#ifndef GENERATE_NEW_CM_MRGN
#define GENERATE_NEW_CM_MRGN

#define FIL_NM_LEN 	18
#define IP_LEN		16
#define	USER_LEN	15
#define	PASS_LEN	15
#define	FILE_PATH_LEN	120
using namespace std;

class Generate_New_CM_Mrgn
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[MAX_FILE_NAME];
		string	server_ip ;
		string	user ;
		string	password ;
		string	file_path ;
		string 	repository_path ;
		string  port ;						
		string  mode ;                    


		FILE	*seq_fp;
		int		recs_printed ;
		int		Generate_New_CM_Mrgn_file();
		int		open_file();
		int		declare_print_contracts();
		int 	RecordsAdded;
		int		MoveFile();
		int		FtpFile();
		vector<string>vszFileNames;
		int     m_iNodeNo ;
		
	public:

		Generate_New_CM_Mrgn(Logger *Log)
		{
			RecordsAdded	=	0;
			Objlogger		=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip.clear() ;
			user.clear() ;
			password.clear() ;
			file_path.clear() ;
			repository_path.clear() ;
			port.clear() ;						
			mode.clear() ;                               
			memset( seq_fname, '\0', MAX_FILE_NAME );
			strcpy( seq_fname,"NCDEX");
		};

		~Generate_New_CM_Mrgn()
		{
			delete ObjconfigurationFileManager;
		};

		int CreateFile(char*);
		int Init(char *);
	
};
#endif
