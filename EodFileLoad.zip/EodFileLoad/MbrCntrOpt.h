#ifndef MBR_CNTR_OPT_FILE
#define MBR_CNTR_OPT_FILE
#include <Logger.h>

#include <MAX_LEN.h>


class MbrCntrOpt
{
	public:
		MbrCntrOpt(Logger* logger);
		int readFileInsertIntoDataBase(char*);
		int sql_stmt;
	private:
        int RecsInstrtd;
        int RecsUpdated;
	Logger *Objlogger;
};
#endif
