#ifndef INCLUDE_COMDTY_MST
#define INCLUDE_COMDTY_MST

#include <Logger.h>
#include <Struct_Comm_Mstr.h>

class 	CommMstr
{
 public:
    CommMstr(Logger *logger);
    int sql_stmt;
	int	readFileInsertIntoDataBase(char* CmdtyFile);
 private:
    Logger *Objlogger;
};
#endif
