/***************************************************************************
* FILE NAME		:    UsrClntCntr.h
*
* CREATION DATE	:	12-JAN-2005
*
* COPYRIGHTS	:   Tata Consultancy Services, Mumbai
*
* CREATED BY	:   Sanjeev Kr. Rana
*
* DESCRIPTION	:	This process transfers data from the Position File in Memory to the database at End-Of-Day.
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details     Remarks
* 1.        <MM-DD-YYYY>        Changed so and so
*
***************************************************************************/
#ifndef INCLUDE_POSITION_FILE
#define INCLUDE_POSITION_FILE
#include<fstream>
#include <Logger.h>

struct StUsrClntCntr;

using namespace std;

class UsrClntCntr
{
	public:
    	UsrClntCntr(Logger *logger );
		int readFileInsertIntoDataBase(char*);	
	private:
		int sql_stmt;
		Logger *Objlogger; //containment used for the logging the activity in the text file.
		int RecsInstrtd;
		int RecsUpdated;
};

#endif
