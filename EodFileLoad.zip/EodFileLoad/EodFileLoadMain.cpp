/***************************************************************************
* FILE NAME		:	OpmsFileLoadMain.cpp 
*
* CREATION DATE	:	12-JAN-2005 
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Sanjeev Kr. Rana
*
* DESCRIPTION	:	Load the data from oracle table into respective file.
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.		<MM-DD-YYYY>		Changed so and so
*
***************************************************************************/

/*#include <iostream>*/
#include "EodFileLoad.h"
#include "EodFtpFiles.h"

#define SQLCA_STORAGE_CLASS extern

using namespace std;
void error_Handler_run(char* fileName,Logger *Objlogger);

int main(  int argc, char **argv )
{
	if ( argc < 5 )
	{
		cerr << "Usage: EodFileLoadMain <program id> <batch date> <oracle SID>  <config file>" << endl ;
		exit ( 1 ) ;
	}
	else
	{
		cout << "****************************************************" << endl ;
		cout << "Program Name : " << argv[0] << endl ;
		cout << "Program ID   : " << argv[1] << endl ;
		cout << "Batch Date   : " << argv[2] << endl ;
		cout << "Oracle SID   : " << argv[3] << endl ;
		cout << "Config file  : " << argv[4] << endl ;
		cout << "****************************************************" << endl ;
	}

/***********object pointers for loading the data from oracle into files is declared here********/
	ConfigurationFileManager *ObjconfigurationFileManager =  new ConfigurationFileManager();	 

	Logger *Objlogger =  new Logger();
	if( (Objlogger->initialize( argv[4],(char*)"LOGGER_PARAMETERS") ) != 1 )	
	{
		Objlogger->logMessage(LEVEL_CRITICAL,"Error in Objlogger->initialize for LOGGER_PARAMETERSS");
		Objlogger->logMessage(LEVEL_CRITICAL,"Exiting from program");
		exit(1);
	}

	EodFileFtp*  ptrEodfileFtp = new EodFileFtp(argv[4], ObjconfigurationFileManager, Objlogger);	   
	if( !ptrEodfileFtp )
	{
		Objlogger->logMessage(LEVEL_CRITICAL,"Error in creating EodFileFtp object");
		Objlogger->logMessage(LEVEL_CRITICAL,"Exiting from program");
		exit(1);
	}	

	if( ptrEodfileFtp->Execute() != SUCCESS )
    	{
        	Objlogger->logMessage(LEVEL_CRITICAL,"Error in ptrEodfileFtp->Execute() %s:%d",__FILE__,__LINE__);
        	Objlogger->logMessage(LEVEL_CRITICAL,"Exiting from program");
        	exit(1);
    	}


	EodFileLoad*  ptrEodFileLoad = new EodFileLoad(argv[4], ObjconfigurationFileManager, Objlogger); 
	if( !ptrEodFileLoad )
	{
		Objlogger->logMessage(LEVEL_CRITICAL,"Error in creating EodFileLoad object");
		Objlogger->logMessage(LEVEL_CRITICAL,"Exiting from program");
		exit(1);
	}	
	
	// Rachna:17-Aug-2011: Batch Date passed as parameter in Execute() 
	//if( ptrEodFileLoad->Execute() != SUCCESS )
	if( ptrEodFileLoad->Execute(argv[2]) != SUCCESS )
    	{
        	Objlogger->logMessage(LEVEL_CRITICAL,"Error in ptrEodFileLoad->Execute() %s:%d",__FILE__,__LINE__);
        	Objlogger->logMessage(LEVEL_CRITICAL,"Exiting from program");
        	exit(1);
    	}
								
	Objlogger->logMessage(LEVEL_INFORMATIONAL,"Program Runs Successfully");
	return(0);
}

/****************error handler for run function******************/

void error_Handler_run(char* fileName,Logger *Objlogger)
{
	Objlogger->logMessage(LEVEL_CRITICAL,"Error in run for %s file",fileName);
	Objlogger->logMessage(LEVEL_CRITICAL,"Exiting from program");
	exit(1);
}
/**************************************** End of Program ************************************************/
