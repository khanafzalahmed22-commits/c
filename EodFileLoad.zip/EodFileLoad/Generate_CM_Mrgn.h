/***************************************************************************
* FILE NAME	:	Generate_CM_Mrgn.h
*
* CREATION DATE	:	04-MAY-16	
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	MANOJ	
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks* 
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>

#ifndef Generate_CM_Mrgn
#define Generate_CM_Mrgn

using namespace std;

#define MIS3_FILE_NM_LEN 	50	
#define IP_LEN		16
#define	USER_LEN	15
#define	PASS_LEN	15
#define	FILE_PATH_LEN	120

class Generate_CMMrgn
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[MIS3_FILE_NM_LEN];
		char*	server_ip ;
		char*	user ;
		char*	password ;
		char*	file_path ;
		char* 	repository_path ;
		char*	port ;				//CR06359: Arushi added
		char*   Nas_file_path ; // CR02128

		FILE	*seq_fp;
		int	recs_printed ;
		int	Generate_CMMrgn_file();
		int	open_file();
		int	declare_print_contracts();
		int 	RecordsAdded;
		int	Create_Control();
		int	MoveFile();
		int	FtpFile();
		int     CopyToNas();//CR CR02128 Function to copy the generated file to NAs folder With changed name 
	public:

		Generate_CMMrgn(Logger *Log)
		{
			RecordsAdded	=	0;
			Objlogger	=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip=NULL ;
			user=NULL ;
			password=NULL ;
			file_path=NULL ;
			repository_path=NULL ;
			port=NULL ;				//CR06359: Arushi added
			memset( seq_fname, '\0',MIS3_FILE_NM_LEN);
		};

		~Generate_CMMrgn()
		{
			delete ObjconfigurationFileManager;
			delete server_ip ;
			delete user ;
			delete password ;
			delete file_path ;
			delete repository_path ;
			delete port ;			//CR06359: Arushi added
		};

		int  CreateFile(char*);
		int Init(char *);
	
};
#endif
