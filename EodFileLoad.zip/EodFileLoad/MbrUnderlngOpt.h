/***************************************************************************
* FILE NAME		:	MbrUnderlng.h
*
* CREATION DATE	:	09-AUG-2017
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Sumaiya A
*
* DESCRIPTION	:
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details     Remarks
* 1.
***************************************************************************/

#ifndef INCLUDE_MBR_UNDERLNG_OPT
#define INCLUDE_MBR_UNDERLNG_OPT

#include <Logger.h>
class MbrUnderlngOpt
{
	public:
		MbrUnderlngOpt(Logger *logger );
		int readFileInsertIntoDataBase(char* );
		int sql_stmt;

	private:
		Logger *Objlogger;
};
#endif



/****************************end of the program******************************/
