#ifndef INCLUDE_EXP_CONTRACT_FILE
#define INCLUDE_EXP_CONTRACT_FILE

#include <Logger.h>
#include <Struct_Cntr.h>
#include <MAX_LEN.h>
#include <Struct_Exp_Cntr.h>

class ExpContractFile
{
 public:
	ExpContractFile(Logger *logger);
	int readFileInsertIntoDataBase(char* ContractFilename);
	int sql_stmt;

 private:
	Logger *Objlogger;

	int ObjExpstCntrMst_Out(StExpCntrMst ObjstCntrMst);//this function prints the value of structure
//	int PopulateWeight();
};
#endif
