/***************************************************************************
* FILE NAME: OpmsFileLoad.h
*
* CREATION DATE: 28-DEC-2004
*
* COPYRIGHTS: Tata Consultancy Services, Mumbai
*
* CREATED BY: Suresh k.
*
* DESCRIPTION: 1)
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details     Remarks
* 1.   CR1760   17-Aug-2011    changes for PSN file creation  <By Rachna>   
* 2.   CR01907  25-APR-2012    updating OPM_USR_CLNT_EXP_CNTR <by Rachna> 
***************************************************************************/

#ifndef EODFILELOAD
#define EODFILELOAD

#include <OPMS_DEF.h>
/*#include <iostream.h>*/
#include <stdio.h>
#include <sysHeaders.h>
#include <Logger.h>
#include <ConfigurationFileManager.h>
#include <string>
#include <Struct_Usr_Clnt_Cntr.h>
#include <Struct_Cntr.h>
#include <Struct_Mbr_Mstr.h>
#include <sqlca.h>
#include <DBCommunication.h>
#include <MultiMapMngr.h> 
// FTR07247 : SHUBHAM PATIL (17th-SEPT-2024) : including header file for istream class : START 
#include <sstream>
// FTR07247 : SHUBHAM PATIL (17th-SEPT-2024) : including header file for istream class : END

#include "UsrClntCntr.h"
#include "ContractFile.h"
#include "MbrMstr.h"
#include "MbrClntCntr.h"
#include "MbrCntr.h"
#include "UsrCntr.h"
#include "MbrUndrLng.h"
#include "MbrClntMstr.h"
#include "MbrClntUndrLng.h"
#include "UndrLngMst.h"
#include "UsrClntUndrlng.h"
#include "UsrClnt.h"
#include "ClrMbrMstr.h"
#include "ClrMbrCntr.h"
#include "UsrMstr.h"
#include "Mrgn_VLTN.h"
#include "OI_Vltn.h"
#include "ExpContractFile.h"
#include "Generate_PSN.h"
#include "Generate_CRMS.h"
#include "Generate_Csh_Mrgn.h"
#include "Generate_NCDEX_CAM.h"
//FTR04143:START

#include "Generate_MG12.h"
#include "Generate_MG22.h"
#include "Generate_MG13.h"
#include "Generate_MG23.h"
#include "Generate_MIS3.h"
#include "Generate_SURV_MGN.h"
#include "Generate_SURV_PSN.h"		
#include "Generate_SURV_STL.h"
#include "Generate_MGN.h"
//FTR04143:END
//CR02415:ANANYA:START:DATE:19-MAY-2014:Loading 3 more tables.
#include "CommMstr.h"
#include "MbrCommMstr.h"
#include "MbrClntComm.h"
//CR02415:ANANYA:END:DATE:19-MAY-2014:Loading 3 more tables.
//CR04682:manoj:ADDED:START
#include "Generate_CM_Mrgn.h"
#include "ClrMbrCommMstr.h"
//CR04682:manoj:ADDED:END 
#include "MbrClntCntrOpt.h"
#include "MbrCntrOpt.h"
#include "MbrClntUnderlngOpt.h" //CR04897 : Sumaiya : Added for Options
#include "MbrUnderlngOpt.h" 	//CR04897 : Sumaiya : Added for Options
#include "MbrClntCommOpt.h"		//CR04897 : Sumaiya : Added for Options
#include "MbrCommOptMstr.h"		//CR04897 : Sumaiya : Added for Options
#include "Generate_MG18.h"      //CR06271 : Arushi added
#include "Generate_MG19.h"      //CR06271 : Arushi added
#include "Generate_MG20.h"      //CR07064 : Vinod : Added
#include "Generate_New_TM_Mrgn.h" //CR07104:Vinod:Added
#include "Generate_New_CM_Mrgn.h" //CR07104:Vinod:Added
#include "ASN_Loader.h"//CR06386 MSS Added 

#include "MAX_LEN.h"

using namespace std ;

class EodFileLoad 
{
 private:
    ClrMbrMstr          *ObjClrMbrMstrFile;
    ClrMbrCntr          *ObjClrMbrCntrFile;
    MbrMstr             *ObjMemberMasterFile;
    MbrCntr             *ObjMbrCntrFile;
    MbrUndrLng          *ObjMbrUndrLngFile;
    MbrClntMstr         *ObjMbrClntMstr;
    MbrClntCntr         *ObjMbrClntCntrFile;
    MbrClntUndrLng      *ObjMbrClntUndrLngFile;
    UsrMstr             *ObjUsrMstr;
    UsrCntrMstr         *ObjUsrCntrFile;
    UsrClnt             *ObjUsrClntFile;
    UsrClntUndrlng      *ObjUsrClntUndrlngFile;
    UsrClntCntr		*ObjUsrClntCntrFile;
    Mrgn_VLTN           *ObjMrgn_VLTN;
    OI_VLTN             *ObjOI_Vltn;
    ContractFile        *ObjContractFile;
    UndrLngMst          *ObjUndrLngMstFile;
	//CR02415:ANANYA:START:DATE:19-MAY-2014:Loading 3 more tables.
	CommMstr			*ObjCommMstrFile;
	MbrCommMstr			*ObjMbrCommMstrFile;
	MbrClntComm			*ObjMbrClntCommFile;
	//CR02415:ANANYA:END:DATE:19-MAY-2014:Loading 3 more tables.
    ExpContractFile	*ObjExpContractFile;
	Generate_CRMS	*ObjGenerate_CRMS;
	
    ConfigurationFileManager *ObjconfigurationFileManager;
    Logger 		*Objlogger;
    DbComm          	*ObjDbComm;
    string 		szConfigFile ;
    Generate_PSN	*ObjGenerate_PSN;	//CR1760
    Generate_Csh_Mrgn   *objGCash;		//CR01760 
	Generate_NCDEX_CAM   *objGenerate_NCDEX_CAM;		//CR01760
	/*FTR04143:Ananya:DATE:26-08-2014:START:Delivery margin should be given in the member 
	and interface files on all days between Allocation and Settlement days 
	excluding both days*/
	Generate_MG12				*ObjGenerate_MG12;
	Generate_MG22				*ObjGenerate_MG22;
	Generate_MG13				*ObjGenerate_MG13;
	Generate_MG23				*ObjGenerate_MG23;
	Generate_MIS3               *ObjGenerate_MIS3;
	Generate_SURV_MGN           *ObjGenerate_SURV_MGN;
	Generate_MGN				*ObjGenerate_MGN;
	Generate_SURV_PSN           *ObjGenerate_SURV_PSN;	
	Generate_SURV_STL           *ObjGenerate_SURV_STL;
	Generate_MG18				*ObjGenerate_MG18;         //CR06271: Arushi Added
	Generate_MG19				*ObjGenerate_MG19;         //CR06271: Arushi Added
	Generate_MG20				*ObjGenerate_MG20;         //CR07064 : Vinod Added
	Generate_New_TM_Mrgn        *ObjGenerate_New_TM_Mrgn;
	Generate_New_CM_Mrgn        *ObjGenerate_New_CM_Mrgn;
	/*FTR04143:Ananya:DATE:26-08-2014:END:Delivery margin should be given in the member 
	and interface files on all days between Allocation and Settlement days 
	excluding both days*/
	//CR04682:manoj:ADDED:START
	Generate_CMMrgn				*ObjGenerate_CMMrgn;
	ClrMbrCommMstr				*ObjClrMbrCommMstrFile;
	//CR04682:manoj:ADDED:END

	//CR04897 : Sumaiya : Added for Options : Start	
	MbrClntUnderlngOpt			*ObjMbrClntUnderlngOptFile;
	MbrUnderlngOpt				*ObjMbrUnderlngOptFile;
	MbrClntCommOpt				*ObjMbrClntCommOptFile;
	MbrCommOptMstr				*ObjMbrCommOptMstrFile;
	//CR04897 : Sumaiya : Added for Options : End

	
	MbrClntCntrOpt				*ObjMbrClntCntrOptFile;			//CR04897 : Pritpal : added : 
	MbrCntrOpt					*ObjMbrCntrOptFile;			//CR04897 : Pritpal : added : 
	ASN_Loader					*ObjASN_Loader;//CR06386 by MSS added 
	string 					BMSFileDir;  //CR06936 : Vinod: Added 
	string 					BMS_RPSTRY_path;   //CR06936 : Vinod : Added
	MultiMapMngr 	*ObjMbrClientMultiMapBMS;  //CR06936:Vinod:Added

 public:
	EodFileLoad(char *confFile,ConfigurationFileManager* ObjConfFile,Logger *logger);

	int 		run(char *BatchDt, char *fileName,char* BodEodFlag );
	int 		Connect();
	void 		put_mod(char *,int,char *,int);
	int 		Initialise_Objects();
	int 		PushMrktWideFilesToDataBase();
	int 		DumpFilesToDataBase(char *BatchDate);
	int 		Release();
	int 		PushFileToDataBase(string& , int );
	int 		Execute(char *BatchDate);

	int 		 update_OPM_USR_CLNT_EXP_CNTR(); //CR01907

	// vinit : 12-OCT-2011 : CR01760 : Generation of DSBL_EOD report
	int		Populate_DSBL_EOD_tbl();
	// vinit : 12-OCT-2011 : CR01760 : Generation of DSBL_EOD report
	/*FTR04143:ANANYA:DATE:26-08-2014:START:To populate this table from OPM_MBR_CLNT_MSTR with delivery margin
	and then give the MBR_CLNT_MRGN_DTLS view to NCFE from this table*/
	int		Populate_MBR_CLNT_MRGN_DTLS_tbl();
	/*FTR04143:ANANYA:DATE:26-08-2014:END:To populate this table from OPM_MBR_CLNT_MSTR with delivery margin
	and then give the MBR_CLNT_MRGN_DTLS view to NCFE from this table*/
	int ClearMultiMap(MultiMapMngr*); //CR06936:Vinod : Added
	// FTR07247 : SHUBHAM PATIL (13th-SEPTEMBER-2024) : Declaration for ASN functions : START
	int CheckingOptionExpiry();
	int Populate_OpmOptAsn_From_ASN_File(); 
	// FTR07247 : SHUBHAM PATIL (13th-SEPTEMBER-2024) : Declaration for ASN functions : END

	// FTR07247 : SHUBHAM PATIL (20th-SEPTEMBER-2024) : Declaration for ASN functions : START
	int CreateViewForOPT_ASN_DTLS();
	// FTR07247 : SHUBHAM PATIL (20th-SEPTEMBER-2024) : Declaration for ASN functions : END

	// FTR07247 : SHUBHAM PATIL (23th-SEPT-2024) : Function Delclaration for Date Format : START
	bool ConvertDateFormat( string& );
	bool isValidDate ( char *cp_token );
	// FTR07247 : SHUBHAM PATIL (23th-SEPT-2024) : Function Delclaration for Date Format : END

	// FTR07247 : SHUBHAM PATIL (23th-SEPT-2024) : Function Delclaration for Validation of ASN File Format : START
	int ValidateASNFile ( string ASNFile );
	// FTR07247 : SHUBHAM PATIL (23th-SEPT-2024) : Function Delclaration for Validation of ASN File Format : END


};

#endif //EODFILELOAD
