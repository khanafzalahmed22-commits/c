/***************************************************************************
* FILE NAME: OpmsFileLoad.h
*
* CREATION DATE: 28-DEC-2004
*
* COPYRIGHTS: Tata Consultancy Services, Mumbai
*
* CREATED BY: Suresh k.
*
* DESCRIPTION: 1)
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details     Remarks
* 1.        <MM-DD-YYYY>        Changed so and so
*
***************************************************************************/

#ifndef EODFILEFTP
#define EODFILEFTP

#include <iostream>
#include <fstream>
#include <vector>
#include <Logger.h>
#include <ConfigurationFileManager.h>
#include "GtwyGlobals.h"
#include <Struct_Svr_Status.h>
#include <OPMS_DEF.h>

using namespace std ;
//struct stSvrDtls ;

class EodFileFtp 
{
 private:
	ConfigurationFileManager *ObjconfigurationFileManager;
	Logger 				*Objlogger;
	string 				szConfigFile ;
	stSvrDtls			*m_stSvrStatus ;
	int 				m_iNoOfNodes ;
	vector<string>		m_vszFileName ;
	int 				m_iNoOfFiles ;  
 
 public:
	EodFileFtp(char *confFile,ConfigurationFileManager* ObjConfFile,Logger *logger);

	int 		Initialise();
	int 		ReadStatusFile();
	int 		ReadFilesFromConfig();
	int 		CheckProcessStatus();
	int 		FtpFilesFromNode(int ,string ,string ,string );
	int			MoveFiles(int);
	int 		Execute();
	int			FtpMktWideFiles();
	int         szPort; 					//CR06359:Arushi added
};

#endif //EODFILEFTP
