/***************************************************************************
* FILE NAME		:	Generate_PSN.h
*
* CREATION DATE	:	28-JUL-2005
*
* COPYRIGHTS	:	Tata Consultancy Services, Mumbai
*
* CREATED BY	:	Sonia Joshi
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.	CR1760	19-Aug-2011	moved PSN file creation from EodFileOutput to EodFileLoad process <By Rachna>
*
***************************************************************************/

#include <sqlca.h>
#include <MAX_LEN.h>
#include <ConfigurationFileManager.h>
#include <Logger.h> 
#include <OPMS_DEF.h>
#include <stdio.h>
#include <iostream>
#include <string.h>

#ifndef GENERATE_PSN
#define GENERATE_PSN

#define FIL_NM_LEN 	18
#define IP_LEN		16
#define	USER_LEN	15
#define	PASS_LEN	15
#define	FILE_PATH_LEN	120
using namespace std;

int Dos2UnixCmd(const char* inputFileFullPath); //CR06732: Annapoorna: Added

class Generate_PSN
{
	private:
		Logger  *Objlogger;
		ConfigurationFileManager *ObjconfigurationFileManager;

		char	seq_fname[FIL_NM_LEN];
		char*	server_ip ;
		char*	user ;
		char*	password ;
		char*	file_path ;
		char* 	repository_path ;
		char*   port ;					//CR06359: Arushi added

		FILE	*seq_fp;
		int		recs_printed ;
		int		Generate_PSN_file();
		int		open_file();
		int		declare_print_contracts();
		int 	RecordsAdded;
		int		Create_Control();
		int		MoveFile();
		int		FtpFile();
		string	Ucfbc_Path ;//CR06386 ADDED by MSS 
	public:

		Generate_PSN(Logger *Log)
		{
			RecordsAdded	=	0;
			Objlogger		=	Log;
			recs_printed	=	0;
			ObjconfigurationFileManager = new ConfigurationFileManager();
			server_ip=NULL ;
			user=NULL ;
			password=NULL ;
			file_path=NULL ;
			repository_path=NULL ;
			port=NULL ;									//CR06359: Arushi added
			memset( seq_fname, '\0',FIL_NM_LEN );
			strcpy( seq_fname,"NCDEX");
		};

		~Generate_PSN()
		{
			delete ObjconfigurationFileManager;
			delete server_ip ;
			delete user ;
			delete password ;
			delete file_path ;
			delete repository_path ;
			delete port ;							//CR06359: Arushi added
		};

		int  CreateFile(char*,char*);
		int Init(char *);
		int insertIntoTable(); //CR06386 ADDED by MSS 
};
#endif
