#ifndef INCLUDE_USR_MASTER
#define INCLUDE_USR_MASTER

#include <Logger.h>
class UsrMstr
{
public:

	UsrMstr(Logger *logger);
	int readFileInsertIntoDataBase (char *);
	int sql_stmt;

private:
	Logger *Objlogger;
};
#endif

