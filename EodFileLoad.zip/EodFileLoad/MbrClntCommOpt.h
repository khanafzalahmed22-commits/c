/***************************************************************************
* FILE NAME		:	MbrClntCommOpt.pc
*
* CREATION DATE	:	07-SEP-2017
*
* COPYRIGHTS	: 	Tata Consultancy Services, Mumbai
*
* CREATED BY	: 	Sumaiya Ansari
*
* DESCRIPTION	:	Load the data from oracle table into respective file.
*
* MODIFICATION COMMENTS:
* ---------------------------------------------------------------------------------------
* Sr    CR. NO  Modification Date   Modification Details        Remarks
* 1.
******************************************************************************************/

#ifndef INCLUDE_MBR_CLNT_COMDTY_OPT_FILE
#define INCLUDE_MBR_CLNT_COMDTY_OPT_FILE

#include <Logger.h>
#include <MAX_LEN.h>


class MbrClntCommOpt
{
	public:
		MbrClntCommOpt(Logger* logger);
		int readFileInsertIntoDataBase(char* );
		int sql_stmt;

	private:
		Logger *Objlogger;
		int sqlToInsertData();		
};
#endif

