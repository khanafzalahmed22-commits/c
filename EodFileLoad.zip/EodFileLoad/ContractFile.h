#ifndef INCLUDE_CONTRACT_FILE
#define INCLUDE_CONTRACT_FILE
#include <Logger.h>
#include <Struct_Cntr.h>
#include <MAX_LEN.h>
class ContractFile
{
 public:
	ContractFile(Logger *logger);
	int readFileInsertIntoDataBase(char* ContractFilename);
	int sql_stmt;

 private:
	Logger *Objlogger;

	int ObjstCntrMst_Out(StCntrMst ObjstCntrMst);//this function prints the value of structure
//	int PopulateWeight();
};
#endif
