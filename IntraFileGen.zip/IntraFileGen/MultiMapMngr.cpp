/*************************************************************************
* FILE NAME		: MultiMapMngr.cpp 
*
* CREATION DATE	: 30-DEC-2004
*
* COPYRIGHTS	: Tata Consultancy Services, Mumbai
*
* CREATED BY	: Sonia Joshi
*
* DESCRIPTION	:
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details				 Remarks
***************************************************************************/

#include <MultiMapMngr.h>
#include <Struct_Usr_Clnt_Cntr.h>
#include <fstream>
#include <Struct_Clr_Mbr_Mstr.h>
#include <Struct_Hedge_Clnt.h>
#include <Struct_Undrlng_Tier.h>
#include <Struct_Leg_Priority.h>
#include <Struct_Mbr_Mstr_Sqr.h>
#include <Struct_Mbr_Mstr.h>
#include <Struct_Usr_Mstr.h>
#include <Struct_Usr_Cntr.h>
#include <Struct_UndrLngMst.h>
#include <Struct_Cntr.h>
#include <Struct_Clr_Mbr_Cntr.h>
#include <Struct_Mbr_Clnt_Mstr.h>
#include <Struct_Mbr_Clnt_Undrlng_Tier.h>
#include <Struct_Usr_Clnt_Undrlng_Tier.h>
#include <Struct_Usr_Clnt_Mstr.h>
#include <Struct_Exp_Cntr.h>
#include <Struct_Usr_Clnt_Undrlng.h>
#include <Struct_Mbr_UndrLng.h>
#include <Struct_CMbr_UndrLng.h>
#include <Struct_Mbr_Cntr.h>
#include <Struct_Mbr_Clnt_Undrlng.h>
#include <Struct_Mbr_Clnt_Cntr.h>
#include <Struct_Usr_Clnt_Cntr.h>
using namespace std;
/**************************************************************************
*	FUNCTION SCOPE : public
*	INPUT  PARAMS  : char pointer
*	OUTPUT PARAMS  : 
*	RETURN VALUE   : unsigned
*	DESCRIPTION	: 
	
***************************************************************************/
int MultiMapMngr :: Clear()
{
	ObjMultiMap.clear();
   	return(SUCCESS);
}

MultiMapIterator MultiMapMngr ::  GetStartPtr()
{
	return(ObjMultiMap.begin());
}
/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : data item ( void  pointer) , hash key (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : SUCCESS (1)
*   DESCRIPTION	: pushes data item in right bucket using hash key
***************************************************************************/
int MultiMapMngr :: PushItem(void *ActLoc ,string MultiMapKey)
{
	MultiMapIterator ObjMultiMapIterator;

	ObjMultiMapIterator = ObjMultiMap.insert( MultiMapPair (MultiMapKey, ActLoc) );
	if ( ObjMultiMapIterator == ObjMultiMap.end() )
	{
		Objlogger->logMessage(LEVEL_CRITICAL,"Error in inserting record in ObjMultiMap.",
		__FILE__,__LINE__);
		return(FAIL);
	}

	return SUCCESS;
}

/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : 
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails  
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
void* MultiMapMngr :: SearchItem(string KeyStr)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.find(KeyStr);

	if( ObjMultiMapIterator != ObjMultiMap.end() )
	{
		return (*ObjMultiMapIterator).second;
	}
	else
	{
		return(NULL);
	}
}

/**************************************************************************
*   FUNCTION SCOPE	: public
*   INPUT  PARAMS	: 
*   OUTPUT PARAMS	:
*   RETURN VALUE	: pointer to data item( void pointer)/NULL if Fails  
*   DESCRIPTION		: 
***************************************************************************/
/*
void* MultiMapMngr :: SearchItemInMapinMultimap(string MultiMapStr, string MapStr)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.find(KeyStr);

	if( ObjMultiMapIterator != ObjMultiMap.end() )
	{
		return (*ObjMultiMapIterator).second;
	}
	else
	{
		return(NULL);
	}
}
*/

/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
int MultiMapMngr :: GetIterator_NoOfRecs( string KeyStr, int& NoOfRecs, MultiMapIterator& Itr )
{
	Itr = ObjMultiMap.lower_bound( KeyStr );
if ( Itr != ObjMultiMap.end() )
{
    NoOfRecs = ObjMultiMap.count(KeyStr);
    return (SUCCESS);
}	
		return(FAIL);
/*	Itr = ObjMultiMap.find( KeyStr );
	if( Itr != ObjMultiMap.end() )
	{
		NoOfRecs = ObjMultiMap.count(KeyStr);
		return (SUCCESS);
	}
	else
	{
		return(FAIL);
	}
*/}

/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
int MultiMapMngr :: GetTotRecs()
{
	return ( ObjMultiMap.size() );
}

/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
int MultiMapMngr :: SortedPushItem(void *ActLoc , string MultiMapKey ,string MapKey)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.find(MultiMapKey);

	if(ObjMultiMapIterator == ObjMultiMap.end())
	{
		Map *ObjMap;
		ObjMap = new Map();

		ObjMap->insert(MapPair( MapKey, ActLoc));
		ObjMultiMap.insert( MultiMapPair(MultiMapKey, ObjMap ));
		
		return(SUCCESS);
	}
	else
	{
		((Map*)(*ObjMultiMapIterator).second)->insert( MapPair ( MapKey , ActLoc ));
	}		
	
	return(SUCCESS);
}

/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
int MultiMapMngr :: SortedPushItem(void *ActLoc , string MultiMapKey_Out ,string MultiMapKey_In,Logger *logger)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.find(MultiMapKey_Out);

	if(ObjMultiMapIterator == ObjMultiMap.end())
	{
		MultiMapMngr	*ObjMultiMapMngr;
		ObjMultiMapMngr	=	new MultiMapMngr(logger);
		ObjMultiMapMngr->PushItem(ActLoc,MultiMapKey_In);
		ObjMultiMap.insert( MultiMapPair(MultiMapKey_Out,ObjMultiMapMngr));
		
		return(SUCCESS);
	}
	else
	{
		((MultiMapMngr*)(*ObjMultiMapIterator).second)->PushItem(ActLoc,MultiMapKey_In);
	}		
	
	return(SUCCESS);
}
/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
int MultiMapMngr :: Get_MapItr_NoOfRecs(string MultiMapKey , int& NoOfRecs, MapIterator& Itr)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.find(MultiMapKey);

	if(ObjMultiMapIterator != ObjMultiMap.end())
	{
		Itr = ((Map*)(*ObjMultiMapIterator).second)->begin();
		NoOfRecs = ((Map*)(*ObjMultiMapIterator).second)->size();
		return(SUCCESS);
	}
	return(FAIL);
}
/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
int MultiMapMngr :: Get_MMapItr_NoOfRecs(string MultiMapKey , int& NoOfRecs, MultiMapIterator& Itr)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.find(MultiMapKey);

	if(ObjMultiMapIterator != ObjMultiMap.end())
	{
		NoOfRecs = ((MultiMapMngr*)(*ObjMultiMapIterator).second)->GetTotRecs();
		Itr	=	((MultiMapMngr*)(*ObjMultiMapIterator).second)->GetStartPtr();
		return(SUCCESS);
	}
	return(FAIL);
}

/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION: searches a bucket using hash string if data item found
*					 then returns its pointer else NULL pointer
***************************************************************************/
int MultiMapMngr :: Get_Equal_Range(string MultiMapKey, MultiMapIterator& Itr1, MultiMapIterator& Itr2)
{
	Itr1 = ObjMultiMap.lower_bound(MultiMapKey);
	Itr2 = ObjMultiMap.upper_bound(MultiMapKey);

	return(FAIL);
}

//Vijay : BMS
/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails  
*   DESCRIPTION:
***************************************************************************/
int MultiMapMngr :: DeleteElementsBMS(string key)
{
	Objlogger->logMessage(LEVEL_DEBUG,"key in DeleteElementsBMS = <%s>",key.c_str());

	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.begin();
	string MapStr;

	while(ObjMultiMapIterator != ObjMultiMap.end())
	{
		MapStr = (*ObjMultiMapIterator).first;
		if(MapStr.compare(key) == 0)
		{
			ObjMultiMap.erase(ObjMultiMapIterator++);
		}
		else
			ObjMultiMapIterator++;
	}
	return(SUCCESS);
}

//Vijay : BMS
/**************************************************************************
*   FUNCTION SCOPE	: public
*   INPUT  PARAMS	: hash string (char   pointer)
*   OUTPUT PARAMS	:
*   RETURN VALUE	: pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION		:
***************************************************************************/
int MultiMapMngr :: DeleteSortedMultiMapElementsBMS(string key)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.begin();
	string MapStr;
	
	while(ObjMultiMapIterator != ObjMultiMap.end())
	{
		MapStr = (*ObjMultiMapIterator).first;
		if(MapStr.compare(key) == 0)
		{
			delete((MultiMapMngr*)(*ObjMultiMapIterator).second);
			ObjMultiMap.erase(ObjMultiMapIterator++);
		}
		else
			ObjMultiMapIterator++;
	}
	return(SUCCESS);
}

/**************************************************************************
*   FUNCTION SCOPE : public
*   INPUT  PARAMS  : hash string (char   pointer)
*   OUTPUT PARAMS  :
*   RETURN VALUE   : pointer to data item( void pointer)/NULL if Fails  
*   DESCRIPTION:
***************************************************************************/
int MultiMapMngr :: DeleteElements(string strTMID)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.begin();
	string MapStr,strTM_Id;

	while(ObjMultiMapIterator != ObjMultiMap.end())
	{
		MapStr = (*ObjMultiMapIterator).first;

		strTM_Id = MapStr.substr( MapStr.find_first_of(":",0));
		if(strTM_Id == strTMID)
		{
			ObjMultiMap.erase(ObjMultiMapIterator++);
		}
		else
			ObjMultiMapIterator++;
	}
	return(SUCCESS);
}

/**************************************************************************
*   FUNCTION SCOPE	: public
*   INPUT  PARAMS	: hash string (char   pointer)
*   OUTPUT PARAMS	:
*   RETURN VALUE	: pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION		:
***************************************************************************/
int MultiMapMngr :: DeleteSortedMapElements(string strTMID)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.begin();
	string MapStr,strTM_Id;
	
	while(ObjMultiMapIterator != ObjMultiMap.end())
	{
		MapStr = (*ObjMultiMapIterator).first;
		strTM_Id = MapStr.substr( MapStr.find_first_of(":",0));
		cout<<"Inside DeleteSortedMapElements"<<endl;
		cout<<"strTM_Id : "<<strTM_Id.c_str()<<endl;
		if(strTM_Id == strTMID)
		{
			delete((Map*)(*ObjMultiMapIterator).second);
			ObjMultiMap.erase(ObjMultiMapIterator++);
		}
		else
			ObjMultiMapIterator++;
	}

	return(SUCCESS);
}
/**************************************************************************
*   FUNCTION SCOPE	: public
*   INPUT  PARAMS	: hash string (char   pointer)
*   OUTPUT PARAMS	:
*   RETURN VALUE	: pointer to data item( void pointer)/NULL if Fails
*   DESCRIPTION		:
***************************************************************************/
int MultiMapMngr :: DeleteSortedMultiMapElements(string strTMID)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.begin();
	string MapStr,strTM_Id;
	
	while(ObjMultiMapIterator != ObjMultiMap.end())
	{
		MapStr = (*ObjMultiMapIterator).first;
		strTM_Id = MapStr.substr(0,MapStr.find_first_of(":",0));
		if(strTM_Id == strTMID)
		{
			delete((MultiMapMngr*)(*ObjMultiMapIterator).second);
			ObjMultiMap.erase(ObjMultiMapIterator++);
		}
		else
			ObjMultiMapIterator++;
	}
	return(SUCCESS);
}


int MultiMapMngr :: WriteMapInFile(int cIndex)
{

    string map_file("");
    time_t  currtime;
    time(&currtime);
    char l_datetime[25] = {0};

    strftime ( l_datetime, sizeof(l_datetime) - 1, "%d%m%Y", localtime(&currtime));
    map_file = l_datetime;
	
	char temp[100] = {'\0'} ;
	char strexecution[100] = {'\0'} ;
	//char *CurrWorkingDir;
	string CurrWorkingDir=getcwd(temp,sizeof(temp));
	std::size_t found = CurrWorkingDir.find_last_of("/\\");
	string str2 = CurrWorkingDir.substr(0,found);
	string strmapstring = str2 + "/Data/MAP";	
	sprintf(strexecution,"mkdir -p %s\n", strmapstring.c_str());
    if ( system(strexecution) != 0 )
    {
        cout << "mkdir -p %s"<<strmapstring<<endl;
        return FAIL;
    }


	switch(cIndex)
	{
		case 1:
			map_file = strmapstring + "/NCDEX_BOD_CLRMBRMSTR_"+ map_file + ".txt";
			if(Write_ClrMbrMstr(map_file) != SUCCESS)
				return(FAIL);
			break;
		case 2:
			map_file = strmapstring + "/NCDEX_BOD_HEDGCLNTDTLS_"+ map_file + ".txt";
			if(Write_HedgeClntDtls(map_file) != SUCCESS)
				return(FAIL);
			break;
		case 3:
			map_file = strmapstring + "/NCDEX_BOD_UNDRLYNGTIER_"+ map_file + ".txt";
			if(Write_UndrLngTier(map_file) != SUCCESS)
				return(FAIL);
			break;
		case 4:
			map_file = strmapstring + "/NCDEX_BOD_LEGPRTY_"+ map_file + ".txt";
			if(Write_LegPriority(map_file) != SUCCESS)
				return(FAIL);
			break;
		case 5:
			map_file = strmapstring + "/NCDEX_BOD_TRDMBRMSTR_"+ map_file + ".txt";
			if(Write_TrdMbrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 6:
			map_file = strmapstring + "/NCDEX_BOD_USRMSTR_"+ map_file + ".txt";
			if(Write_UsrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 7:
			map_file = strmapstring + "/NCDEX_BOD_USRCNTRMSTR_"+ map_file + ".txt";
			if(Write_UsrCntrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 8:
			map_file = strmapstring + "/NCDEX_BOD_UNDRLNGMSTR_"+ map_file + ".txt";
			if(Write_UndrLngMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 9:
			map_file = strmapstring + "/NCDEX_BOD_CNTRMSTR_"+ map_file + ".txt";
			if(Write_CntrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 10:
			map_file = strmapstring + "/NCDEX_BOD_CLRMBRCNTRMSTR_"+ map_file + ".txt";
			if(Write_ClrMbrCntrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 11:
			map_file = strmapstring + "/NCDEX_BOD_MBRCLNTMSTR_"+ map_file + ".txt";
			if(Write_MbrClntMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 12:
			map_file = strmapstring + "/NCDEX_BOD_MBRCLNTUNDRLNGTIER_"+ map_file + ".txt";
			if(Write_MbrClntUndrLngTier(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 13:
			map_file = strmapstring + "/NCDEX_BOD_USRCLNTUNDRLNGTIER_"+ map_file + ".txt";
			if(Write_UsrClntUndrLngTier(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 14:
			map_file = strmapstring + "/NCDEX_BOD_USRCLNTMSTR_"+ map_file + ".txt";
			if(Write_UsrClntMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 15:
			map_file = strmapstring + "/NCDEX_BOD_EXPCNTRMSTR_"+ map_file + ".txt";
			if(Write_ExpContractMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 16:
			map_file = strmapstring + "/NCDEX_BOD_USRCLNTUNDRLNGMSTR_"+ map_file + ".txt";
			if(Write_UsrClntUndrLngMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 17:
			map_file = strmapstring + "/NCDEX_BOD_TRDMBRUNDRLNGMSTR_"+ map_file + ".txt";
			if(Write_TrdMbrUndrLngMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 18:
			map_file = strmapstring + "/NCDEX_BOD_CLRMBRUNDRLNGMSTR_"+ map_file + ".txt";
			if(Write_ClrMbrUndrLngMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 19:
			map_file = strmapstring + "/NCDEX_BOD_TRDMBRCNTRMSTR_"+ map_file + ".txt";
			if(Write_TrdMbrCntrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 20:
			map_file = strmapstring + "/NCDEX_BOD_MBRCLNTUNDRLNGMSTR_"+ map_file + ".txt";
			if(Write_MbrClntUndrLngMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 21:
			map_file = strmapstring + "/NCDEX_BOD_MBRCLNTCNTRMSTR_"+ map_file + ".txt";
			if(Write_MbrClntCntrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
		case 22:
			map_file = strmapstring + "/NCDEX_BOD_USRCLNTCNTRMSTR_"+ map_file + ".txt";
			if(Write_UsrClntCntrMstr(map_file) != SUCCESS)
				return(FAIL);
			break; 
	}				
	return SUCCESS;
}

int MultiMapMngr :: WriteMapInFileAtEOD(int cIndex)
{

    string map_file("");
    time_t  currtime;
    time(&currtime);
    char l_datetime[25] = {0};

    strftime ( l_datetime, sizeof(l_datetime) - 1, "%d%m%Y", localtime(&currtime));
    map_file = l_datetime;
	
	char temp[100] = {'\0'} ;
	char strexecution[100] = {'\0'} ;
	//char *CurrWorkingDir;
	string CurrWorkingDir=getcwd(temp,sizeof(temp));
	std::size_t found = CurrWorkingDir.find_last_of("/\\");
	string str2 = CurrWorkingDir.substr(0,found);
	string strmapstring = str2 + "/Data/MAP";
	sprintf(strexecution,"mkdir -p %s\n", strmapstring.c_str());
   if ( system(strexecution) != 0 )
    {
        cout << "mkdir -p %s"<<strmapstring<<endl;
        return FAIL;
    }


    switch(cIndex)
    {
        case 1:
            map_file = strmapstring + "/NCDEX_EOD_CLRMBRMSTR_"+ map_file + ".txt";
            if(Write_ClrMbrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 2:
            map_file = strmapstring + "/NCDEX_EOD_HEDGCLNTDTLS_"+ map_file + ".txt";
            if(Write_HedgeClntDtls(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 3:
            map_file = strmapstring + "/NCDEX_EOD_UNDRLYNGTIER_"+ map_file + ".txt";
            if(Write_UndrLngTier(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 4:
            map_file =  strmapstring + "/NCDEX_EOD_LEGPRTY_"+ map_file + ".txt";
            if(Write_LegPriority(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 5:
            map_file = strmapstring + "/NCDEX_EOD_TRDMBRMSTR_"+ map_file + ".txt";
            if(Write_TrdMbrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 6:
            map_file = strmapstring + "/NCDEX_EOD_USRMSTR_"+ map_file + ".txt";
            if(Write_UsrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 7:
            map_file = strmapstring + "/NCDEX_EOD_USRCNTRMSTR_"+ map_file + ".txt";
            if(Write_UsrCntrMstr(map_file) != SUCCESS)
                return(FAIL);
			break;
        case 8:
            map_file = strmapstring + "/NCDEX_EOD_UNDRLNGMSTR_"+ map_file + ".txt";
            if(Write_UndrLngMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 9:
            map_file = strmapstring + "/NCDEX_EOD_CNTRMSTR_"+ map_file + ".txt";
            if(Write_CntrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 10:
            map_file = strmapstring + "/NCDEX_EOD_CLRMBRCNTRMSTR_"+ map_file + ".txt";
            if(Write_ClrMbrCntrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 11:
            map_file = strmapstring + "/NCDEX_EOD_MBRCLNTMSTR_"+ map_file + ".txt";
            if(Write_MbrClntMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 12:
            map_file = strmapstring + "/NCDEX_EOD_MBRCLNTUNDRLNGTIER_"+ map_file + ".txt";
            if(Write_MbrClntUndrLngTier(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 13:
            map_file = strmapstring + "/NCDEX_EOD_USRCLNTUNDRLNGTIER_"+ map_file + ".txt";
            if(Write_UsrClntUndrLngTier(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 14:
            map_file = strmapstring + "/NCDEX_EOD_USRCLNTMSTR_"+ map_file + ".txt";
            if(Write_UsrClntMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 15:
            map_file = strmapstring + "/NCDEX_EOD_EXPCNTRMSTR_"+ map_file + ".txt";
            if(Write_ExpContractMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 16:
            map_file = strmapstring + "/NCDEX_EOD_USRCLNTUNDRLNGMSTR_"+ map_file + ".txt";
            if(Write_UsrClntUndrLngMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 17:
            map_file = strmapstring + "/NCDEX_EOD_TRDMBRUNDRLNGMSTR_"+ map_file + ".txt";
            if(Write_TrdMbrUndrLngMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 18:
            map_file = strmapstring + "/NCDEX_EOD_CLRMBRUNDRLNGMSTR_"+ map_file + ".txt";
            if(Write_ClrMbrUndrLngMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 19:
            map_file = strmapstring + "/NCDEX_EOD_TRDMBRCNTRMSTR_"+ map_file + ".txt";
            if(Write_TrdMbrCntrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 20:
            map_file = strmapstring + "/NCDEX_EOD_MBRCLNTUNDRLNGMSTR_"+ map_file + ".txt";
            if(Write_MbrClntUndrLngMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 21:
            map_file = strmapstring + "/NCDEX_EOD_MBRCLNTCNTRMSTR_"+ map_file + ".txt";
            if(Write_MbrClntCntrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
        case 22:
            map_file = strmapstring + "/NCDEX_EOD_USRCLNTCNTRMSTR_"+ map_file + ".txt";
            if(Write_UsrClntCntrMstr(map_file) != SUCCESS)
                return(FAIL);
            break;
    }
    return SUCCESS;
}




int MultiMapMngr :: Write_ClrMbrMstr(string File)
{
	int  count   = 0;
	long MapSize = 0;
	long KeySize = 0;
	long ValSize = 0; 
	string key;

	MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	struct  StClrMbrMstr*   ObjClrMbrMstr = NULL;
	
    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

		count++;
		key = (*ObjMultiMapIterator).first;

		ObjClrMbrMstr = (struct StClrMbrMstr *)(*ObjMultiMapIterator).second;
		
		filestr<<"Ocmm_Cmbr_Id:"<<ObjClrMbrMstr->Ocmm_Cmbr_Id<<", ";
		filestr<<"Ocmm_Cmbr_Prim_Mem_Code:"<<ObjClrMbrMstr->Ocmm_Cmbr_Prim_Mem_Code<<", ";
		filestr<<"Ocmm_Cmbr_Name:"<<ObjClrMbrMstr->Ocmm_Cmbr_Name<<", ";
		filestr<<"Ocmm_Stat_Flg:"<<ObjClrMbrMstr->Ocmm_Stat_Flg<<", ";
		filestr<<"Ocmm_Cmbr_Typ:"<<ObjClrMbrMstr->Ocmm_Cmbr_Typ<<", ";
		filestr<<"Ocmm_Col_Lmt:"<<ObjClrMbrMstr->Ocmm_Col_Lmt<<", ";
		filestr<<"Ocmm_MTM_PL:"<<ObjClrMbrMstr->Ocmm_MTM_PL<<", ";
		filestr<<"Ocmm_Initial_Margin:"<<ObjClrMbrMstr->Ocmm_Initial_Margin<<", ";
		filestr<<"Ocmm_Exp_Margin:"<<ObjClrMbrMstr->Ocmm_Exp_Margin<<", ";
		filestr<<"Ocmm_Pre_Exp_Margin:"<<ObjClrMbrMstr->Ocmm_Pre_Exp_Margin<<", ";
		filestr<<"Ocmm_Adhc_Margin:"<<ObjClrMbrMstr->Ocmm_Adhc_Margin<<", ";
		filestr<<"Ocmm_Dlvry_Margin:"<<ObjClrMbrMstr->Ocmm_Dlvry_Margin<<", ";
		filestr<<"Ocmm_Tot_Eff_Depst:"<<ObjClrMbrMstr->Ocmm_Tot_Eff_Depst<<", ";
		filestr<<"Ocmm_Eff_Depst_Bod:"<<ObjClrMbrMstr->Ocmm_Eff_Depst_Bod<<", ";
		filestr<<"Ocmm_Min_Base_Capt:"<<ObjClrMbrMstr->Ocmm_Min_Base_Capt<<", ";
		filestr<<"Ocmm_Init_Mrgn_Limit:"<<ObjClrMbrMstr->Ocmm_Init_Mrgn_Limit<<", ";
		filestr<<"Ocmm_Amt_Avlfor_Imrgn:"<<ObjClrMbrMstr->Ocmm_Amt_Avlfor_Imrgn<<", ";
		filestr<<"Ocmm_Expsr_Mrgn_lmt:"<<ObjClrMbrMstr->Ocmm_Expsr_Mrgn_lmt<<", ";
		filestr<<"Ocmm_Alrt_Prctn_Sent_EM:"<<ObjClrMbrMstr->Ocmm_Alrt_Prctn_Sent_EM<<", ";
		filestr<<"Ocmm_Alrt_Prctn_Sent_IM:"<<ObjClrMbrMstr->Ocmm_Alrt_Prctn_Sent_IM<<", ";
		filestr<<"Ocmm_Undrctnl_Mrgn:"<<ObjClrMbrMstr->Ocmm_Undrctnl_Mrgn<<", ";
		filestr<<"Ocmm_Conc_Mrgn:"<<ObjClrMbrMstr->Ocmm_Conc_Mrgn<<", ";
		filestr<<"Ocmm_Pay_In:"<<ObjClrMbrMstr->Ocmm_Pay_In<<", ";
		filestr<<"Ocmm_Pay_Out:"<<ObjClrMbrMstr->Ocmm_Pay_Out<<", ";
		filestr<<"Ocmm_Enbl_Sent:"<<ObjClrMbrMstr->Ocmm_Enbl_Sent<<", ";
		filestr<<"Ocmm_Fnds_Shrtge:"<<ObjClrMbrMstr->Ocmm_Fnds_Shrtge<<", ";
		filestr<<"Ocmm_Enbl_Time:"<<ObjClrMbrMstr->Ocmm_Enbl_Time<<", ";
		filestr<<"Ocmm_Enbl_By:"<<ObjClrMbrMstr->Ocmm_Enbl_By<<", ";
		filestr<<"Ocmm_Enbl_Rsn:"<<ObjClrMbrMstr->Ocmm_Enbl_Rsn<<", ";
		filestr<<"Ocmm_EL_Mrgn:"<<ObjClrMbrMstr->Ocmm_EL_Mrgn;          //SHRAMIK:CR04502 - Added for ELM
		filestr<<"Ocmm_Net_Buy_Premium:"<<ObjClrMbrMstr->Ocmm_Net_Buy_Premium<<", "; //Suhas: added: CR04897: NBP
		filestr<<"Ocmm_Margin_disablementFlag:"<<ObjClrMbrMstr->Ocmm_Margin_disablementFlag<<", "; //CR04955 : Pritpal : added : 
		filestr<<endl;
			
    }

	KeySize = count * (key.size()); 
	ValSize = count * (sizeof(StClrMbrMstr));
	MapSize = KeySize + ValSize;
	
	filestr<<endl<<"No of Rec is:"<<count<<endl;
	filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
	filestr<<"Total Map Size is:"<<MapSize<<endl;
	filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
	return SUCCESS;
}

int MultiMapMngr :: Write_HedgeClntDtls(string File)
{

	int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
 	struct StHedgeClient *ObjStHedgeClient = NULL ;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {
	
	    count++;
        key = (*ObjMultiMapIterator).first;    

        ObjStHedgeClient = (struct StHedgeClient*)(*ObjMultiMapIterator).second;

        filestr<<"Ohc_Hdg_Cmbr_Id:"<<ObjStHedgeClient->Ohc_Hdg_Cmbr_Id<<", ";
        filestr<<"Ohc_Hdg_Tmbr_Id:"<<ObjStHedgeClient->Ohc_Hdg_Tmbr_Id<<", ";
        filestr<<"Ohc_Hdg_Clnt_Id:"<<ObjStHedgeClient->Ohc_Hdg_Clnt_Id<<", ";
        filestr<<"Ohc_Smbl:"<<ObjStHedgeClient->Ohc_Smbl<<", ";
        filestr<<"Ohc_Undrlng_Tokn_Nm:"<<ObjStHedgeClient->Ohc_Undrlng_Tokn_Nm<<", ";
        filestr<<"Ohc_Position_Flag:"<<ObjStHedgeClient->Ohc_Position_Flag<<", ";
        filestr<<"Ohc_Hdg_Clnt_Oi_Lmt:"<<ObjStHedgeClient->Ohc_Hdg_Clnt_Oi_Lmt<<", ";
        filestr<<"Ohc_Hdg_Clnt_Oi_Prc_Lmt:"<<ObjStHedgeClient->Ohc_Hdg_Clnt_Oi_Prc_Lmt<<", ";
        filestr<<"Ohc_Hdg_Clnt_Oi_Vle_Lmt:"<<ObjStHedgeClient->Ohc_Hdg_Clnt_Oi_Vle_Lmt;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
	filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;

    filestr<<"Total Map Size is:"<<MapSize<<endl;

    filestr.close();
    return SUCCESS;
}


int MultiMapMngr :: Write_UndrLngTier(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	struct StUndrLngTier *ObjUndrLngTier = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

    	count++;
    	key = (*ObjMultiMapIterator).first;    

        ObjUndrLngTier = (struct StUndrLngTier*)(*ObjMultiMapIterator).second;

        filestr<<"Out_Smbl:"<<ObjUndrLngTier->Out_Smbl<<", ";
        filestr<<"Out_Tier:"<<ObjUndrLngTier->Out_Tier<<", ";
        filestr<<"Out_Mnth1:"<<ObjUndrLngTier->Out_Mnth1<<", ";
        filestr<<"Out_Mnth2:"<<ObjUndrLngTier->Out_Mnth2<<", ";
        filestr<<"Out_Tokn_Nm:"<<ObjUndrLngTier->Out_Tokn_Nm<<", ";
        filestr<<"Out_Charge:"<<ObjUndrLngTier->Out_Charge<<", ";
        filestr<<"Out_Grad_Red_Fact:"<<ObjUndrLngTier->Out_Grad_Red_Fact<<", ";
        filestr<<"Out_Lng_Undrctnl_Mrgn_Prcntg:"<<ObjUndrLngTier->Out_Lng_Undrctnl_Mrgn_Prcntg<<", ";
        filestr<<"Out_Shrt_Undrctnl_Mrgn_Prcntg:"<<ObjUndrLngTier->Out_Shrt_Undrctnl_Mrgn_Prcntg<<", ";
        filestr<<"Out_Adhc_Lng_Mrgn_Prcntg:"<<ObjUndrLngTier->Out_Adhc_Lng_Mrgn_Prcntg<<", ";
        filestr<<"Out_Adhc_Shrt_Mrgn_Prcntg:"<<ObjUndrLngTier->Out_Adhc_Shrt_Mrgn_Prcntg;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;

    filestr.close();
    return SUCCESS;
}


int MultiMapMngr :: Write_LegPriority(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	
	struct StLegPriority *LegPrioObj	= NULL;	

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        LegPrioObj = (struct StLegPriority*)(*ObjMultiMapIterator).second;

        filestr<<"Olp_Smbl:"<<LegPrioObj->Olp_Smbl<<", ";
        filestr<<"Olp_Tot_Legs:"<<LegPrioObj->Olp_Tot_Legs<<", ";
        filestr<<"Olp_TierLeg->Tier_Id:"<<LegPrioObj->Olp_TierLeg->Tier_Id<<", ";
        filestr<<"Olp_TierLeg->Mrkt_Dir:"<<LegPrioObj->Olp_TierLeg->Mrkt_Dir<<", ";
        filestr<<"Olp_TierLeg->Delta:"<<LegPrioObj->Olp_TierLeg->Delta<<", ";
        filestr<<"Olp_Leg_Prio:"<<LegPrioObj->Olp_Leg_Prio;
        //filestr<<"Olp_IM_Mult:"<<LegPrioObj->Olp_IM_Mult<<", ";      //SHRAMIK:CR04501 - Commented IM multiplier
        //filestr<<"Olp_EM_Mult:"<<LegPrioObj->Olp_EM_Mult;            //SHRAMIK:CR04502 - Commented ELM multiplier

        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_TrdMbrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	struct StMbrMstr  *objStMbrMstr	= NULL;


    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        objStMbrMstr	= (struct StMbrMstr*)(*ObjMultiMapIterator).second;

        filestr<<"Otmms_Tmbr_Id:"<<objStMbrMstr->Otmm_Tmbr_Id<<", ";
        filestr<<"Otmms_Tmbr_Name:"<<objStMbrMstr->Otmm_Tmbr_Name<<", ";
        filestr<<"Otmms_Cmbr_Id:"<<objStMbrMstr->Otmm_Cmbr_Id<<", ";
        filestr<<"Otmms_Stat_Flg:"<<objStMbrMstr->Otmm_Stat_Flg<<", ";
        filestr<<"Otmms_Sqr_Off_Token:"<<objStMbrMstr->Otmm_Sqr_Off_Token<<", ";
        filestr<<"Otmms_Vrtl_Port_Flg:"<<objStMbrMstr->Otmm_Vrtl_Port_Flg<<", ";
        filestr<<"Otmms_Mem_Typ:"<<objStMbrMstr->Otmm_Mem_Typ<<", ";
        filestr<<"Otmms_Init_Margin_les_NBP:"<<objStMbrMstr->Otmm_Init_Margin_les_NBP<<", ";
        filestr<<"Otmms_Init_Margin:"<<objStMbrMstr->Otmm_Init_Margin<<", ";
        filestr<<"Otmms_Exp_Margin:"<<objStMbrMstr->Otmm_Exp_Margin<<", ";
        filestr<<"Otmms_Adhoc_Margin:"<<objStMbrMstr->Otmm_Adhoc_Margin<<", ";
        filestr<<"Otmms_Dlvry_Margin:"<<objStMbrMstr->Otmm_Dlvry_Margin<<", ";
        filestr<<"Otmms_Tot_Mrgn_Lmt:"<<objStMbrMstr->Otmm_Tot_Mrgn_Lmt<<", ";
        filestr<<"Otmms_Undrctnl_Mrgn:"<<objStMbrMstr->Otmm_Undrctnl_Mrgn<<", ";
        filestr<<"Otmms_Conc_Mrgn:"<<objStMbrMstr->Otmm_Conc_Mrgn<<", ";
		filestr<<"Otmm_EL_Mrgn:"<<objStMbrMstr->Otmm_EL_Mrgn;          //SHRAMIK:CR04502 - Added for ELM
		filestr<<"Otmm_Net_Buy_Premium:"<<objStMbrMstr->Otmm_Net_Buy_Premium; //Suhas: added: CR04897: NBP
		filestr<<"Otmm_Margin_Flag:"<<objStMbrMstr->Otmm_Margin_Flag;		//CR04955 : Pritpal : 
		//filestr<<"Otmm_Pledge_Collateral:"<<objStMbrMstr->Otmm_Pledge_Collateral;		//CR06489 : Pritpal : 
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}


int MultiMapMngr :: Write_UsrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	struct StUsrMstr *UserMmryObj = NULL;


    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        UserMmryObj = (struct StUsrMstr*)(*ObjMultiMapIterator).second;

        filestr<<"Oum_Cmbr_Id:"<<UserMmryObj->Oum_Cmbr_Id<<", ";
        filestr<<"Oum_Tmbr_Id:"<<UserMmryObj->Oum_Tmbr_Id<<", ";
        filestr<<"Oum_Usr_Id:"<<UserMmryObj->Oum_Usr_Id<<", ";
        filestr<<"Oum_Status:"<<UserMmryObj->Oum_Status<<", ";
        filestr<<"Oum_Mtm_Pl:"<<UserMmryObj->Oum_Mtm_Pl<<", ";
        filestr<<"Oum_Mrgn_Lmt:"<<UserMmryObj->Oum_Mrgn_Lmt<<", ";
        filestr<<"Oum_Init_Mrgn:"<<UserMmryObj->Oum_Init_Mrgn<<", ";
        filestr<<"Oum_Exp_Mrgn:"<<UserMmryObj->Oum_Exp_Mrgn<<", ";
        filestr<<"Oum_Pre_Exp_Mrgn:"<<UserMmryObj->Oum_Pre_Exp_Mrgn<<", ";
        filestr<<"Oum_Adhc_Mrgn:"<<UserMmryObj->Oum_Adhc_Mrgn<<", ";
        filestr<<"Oum_Alrt_Prctn_Sent:"<<UserMmryObj->Oum_Alrt_Prctn_Sent<<", ";
        filestr<<"Oum_Enbl_Time:"<<UserMmryObj->Oum_Enbl_Time<<", ";
        filestr<<"Oum_Enbl_By:"<<UserMmryObj->Oum_Enbl_By<<", ";
        filestr<<"Oum_Enbl_Rsn:"<<UserMmryObj->Oum_Enbl_Rsn<<", ";
        filestr<<"Oum_Undrctnl_Mrgn:"<<UserMmryObj->Oum_Undrctnl_Mrgn<<", ";
		filestr<<"Oum_EL_Mrgn:"<<UserMmryObj->Oum_EL_Mrgn;   //SHRAMIK:CR04502 - Added for ELM
		filestr<<"Oum_Net_Buy_Premium:"<<UserMmryObj->Oum_Net_Buy_Premium;	//Suhas: added: CR04897: NBP
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 3 times in multimap so Net Total Size:"<<MapSize*3;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_UsrCntrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	struct StUsrCntr    *UsrCntrObj = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        UsrCntrObj= (struct StUsrCntr*)(*ObjMultiMapIterator).second;

        filestr<<"Ouc_Cmbr_Id:"<<UsrCntrObj->Ouc_Cmbr_Id<<", ";
        filestr<<"Ouc_Tmbr_Id:"<<UsrCntrObj->Ouc_Tmbr_Id<<", ";
        filestr<<"Ouc_User_Id:"<<UsrCntrObj->Ouc_User_Id<<", ";
        filestr<<"Ouc_Tokn_Nm:"<<UsrCntrObj->Ouc_Tokn_Nm<<", ";
        filestr<<"Ouc_Long_Oi:"<<UsrCntrObj->Ouc_Long_Oi<<", ";
        filestr<<"Ouc_Shrt_Oi:"<<UsrCntrObj->Ouc_Shrt_Oi<<", ";
        filestr<<"Ouc_Long_Oi_Value:"<<UsrCntrObj->Ouc_Long_Oi_Value<<", ";
        filestr<<"Ouc_Shrt_Oi_Value:"<<UsrCntrObj->Ouc_Shrt_Oi_Value;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}


int MultiMapMngr :: Write_UndrLngMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	struct StUndrLngMst *stUndrlngMstr = NULL;


    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;
    
        stUndrlngMstr= (struct StUndrLngMst*)(*ObjMultiMapIterator).second;

        filestr<<"Oum_Smbl:"<<stUndrlngMstr->Oum_Smbl<<", ";
        filestr<<"Oum_Undrlng_Tokn_Nm:"<<stUndrlngMstr->Oum_Undrlng_Tokn_Nm<<", ";
        filestr<<"Oum_Exp_Mrgn_Mlt:"<<stUndrlngMstr->Oum_Exp_Mrgn_Mlt<<", ";
        //filestr<<"Oum_Pre_Exp_Mrgn_Mlt:"<<stUndrlngMstr->Oum_Pre_Exp_Mrgn_Mlt<<", ";//PRE-EXP REDESIGN 10FEB2011
        filestr<<"Oum_Som_Chrg:"<<stUndrlngMstr->Oum_Som_Chrg<<", ";
        filestr<<"Oum_Stlmnt_Prce:"<<stUndrlngMstr->Oum_Stlmnt_Prce<<", ";
        filestr<<"Oum_Exp_Stlmnt_Prce:"<<stUndrlngMstr->Oum_Exp_Stlmnt_Prce<<", ";
        filestr<<"Oum_Lkahd_Dys_Dlvr_Mrg:"<<stUndrlngMstr->Oum_Lkahd_Dys_Dlvr_Mrg<<", ";
		 //filestr<<"Oum_Min_Dlvr_Mnth_Chrg:"<<stUndrlngMstr->Oum_Min_Dlvr_Mnth_Chrg<<", ";    
		//CR02087 : start: To seperate Min Dlv Month Charge for Buy and Sell
        filestr<<"Oum_Min_Dlvr_Mnth_Chrg_Lng:"<<stUndrlngMstr->Oum_Min_Dlvr_Mnth_Chrg_Lng<<", ";    
        filestr<<"Oum_Min_Dlvr_Mnth_Chrg_Shrt:"<<stUndrlngMstr->Oum_Min_Dlvr_Mnth_Chrg_Shrt<<", ";
		//CR02087 : end: To seperate Min Dlv Month Charge for Buy and Sell
        filestr<<"Oum_Vsr:"<<stUndrlngMstr->Oum_Vsr<<", ";
        filestr<<"Oum_Sgm_Mlt:"<<stUndrlngMstr->Oum_Sgm_Mlt<<", ";
        filestr<<"Oum_Lkahd_Dys_Psr:"<<stUndrlngMstr->Oum_Lkahd_Dys_Psr<<", ";
        filestr<<"Oum_Fut_Oi:"<<stUndrlngMstr->Oum_Fut_Oi<<", ";
        filestr<<"Oum_Fut_Oi_Value:"<<stUndrlngMstr->Oum_Fut_Oi_Value<<", ";
        filestr<<"Oum_Itm_Opt_Oi:"<<stUndrlngMstr->Oum_Itm_Opt_Oi<<", ";
        filestr<<"Oum_Itm_Opt_Oi_Value:"<<stUndrlngMstr->Oum_Itm_Opt_Oi_Value<<", ";
        filestr<<"Oum_Init_Base_Vlty:"<<stUndrlngMstr->Oum_Init_Base_Vlty<<", ";
        filestr<<"Oum_Vlty:"<<stUndrlngMstr->Oum_Vlty<<", ";
        filestr<<"Oum_Min_Init_Mrgn_Prcntg:"<<stUndrlngMstr->Oum_Min_Init_Mrgn_Prcntg<<", ";
        filestr<<"Oum_Icc_Flag:"<<stUndrlngMstr->Oum_Icc_Flag<<", ";
        filestr<<"Oum_Oi_Redn_Flg:"<<stUndrlngMstr->Oum_Oi_Redn_Flg<<", ";
        filestr<<"Oum_Clnt_Oi_Lmt:"<<stUndrlngMstr->Oum_Clnt_Oi_Lmt<<", ";
        filestr<<"Oum_Clnt_Oi_Prcntg:"<<stUndrlngMstr->Oum_Clnt_Oi_Prcntg<<", ";
        filestr<<"Oum_Clnt_Oi_Val:"<<stUndrlngMstr->Oum_Clnt_Oi_Val<<", ";
        filestr<<"Oum_Mbr_Oi_Lmt:"<<stUndrlngMstr->Oum_Mbr_Oi_Lmt<<", ";
        filestr<<"Oum_Mbr_Oi_Prcntg:"<<stUndrlngMstr->Oum_Mbr_Oi_Prcntg<<", ";
        filestr<<"Oum_Mbr_Oi_Val:"<<stUndrlngMstr->Oum_Mbr_Oi_Val<<", ";
        filestr<<"Oum_Undrlng_Oi_Lmt:"<<stUndrlngMstr->Oum_Undrlng_Oi_Lmt<<", ";
        filestr<<"Oum_Undrlng_Oi_Val_Lmt:"<<stUndrlngMstr->Oum_Undrlng_Oi_Val_Lmt<<", ";
		for(int i =0; i<17; i++)
		{
        	filestr<<"Oum_Dlt_Wt["<<i<<"]:"<<stUndrlngMstr->Oum_Dlt_Wt[i]<<", ";
		}
        filestr<<"Oum_Fut_Alrt_Prctn_Sent:"<<stUndrlngMstr->Oum_Fut_Alrt_Prctn_Sent<<", ";
        filestr<<"Oum_Opt_Alrt_Prctn_Sent:"<<stUndrlngMstr->Oum_Opt_Alrt_Prctn_Sent<<", ";
        filestr<<"Oum_Init_Spot_Base_Vlty:"<<stUndrlngMstr->Oum_Init_Spot_Base_Vlty<<", ";
        filestr<<"Oum_Spot_Vlty:"<<stUndrlngMstr->Oum_Spot_Vlty<<", ";
		filestr<<"Oum_Lng_Pe_Mrgn_Prcntg:"<<stUndrlngMstr->Oum_Lng_Pe_Mrgn_Prcntg<<", ";//PRE-EXP REDESIGN 10FEB2011
		filestr<<"Oum_Shrt_Pe_Mrgn_Prcntg:"<<stUndrlngMstr->Oum_Shrt_Pe_Mrgn_Prcntg<<", ";//PRE-EXP REDESIGN 10FEB2011
		filestr<<"Oum_Epi_Flg:"<<stUndrlngMstr->Oum_Epi_Flg<<", ";//LOK EPI Flg Changes 21JUN2011
		filestr<<"Oum_EL_Mrgn_Mlt:"<<stUndrlngMstr->Oum_EL_Mrgn_Mlt;   //SHRAMIK:CR04502 - Added for ELM
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_CntrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

 	struct StCntrMst  *stCntrMst = NULL;
    
	filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        stCntrMst= (struct StCntrMst*)(*ObjMultiMapIterator).second;
		
        filestr<<"Ocm_Tokn_Nm:"<<stCntrMst->Ocm_Tokn_Nm<<", ";
        filestr<<"Ocm_Inst_Typ:"<<stCntrMst->Ocm_Inst_Typ<<", ";
        filestr<<"Ocm_Smbl:"<<stCntrMst->Ocm_Smbl<<", ";
        filestr<<"Ocm_Exp_Dt:"<<stCntrMst->Ocm_Exp_Dt<<", ";
        filestr<<"Ocm_Sers:"<<stCntrMst->Ocm_Sers<<", ";
        filestr<<"Ocm_Mkt_Typ:"<<stCntrMst->Ocm_Mkt_Typ<<", ";
        filestr<<"Ocm_Optn_Typ:"<<stCntrMst->Ocm_Optn_Typ<<", ";
        filestr<<"Ocm_Strk_Prc:"<<stCntrMst->Ocm_Strk_Prc<<", ";
        filestr<<"Ocm_Ca_Lvl:"<<stCntrMst->Ocm_Ca_Lvl<<", ";
        filestr<<"Ocm_Undrlng_Tokn_Nm:"<<stCntrMst->Ocm_Undrlng_Tokn_Nm<<", ";
        filestr<<"Ocm_Fut_Opt_Flg:"<<stCntrMst->Ocm_Fut_Opt_Flg<<", ";
        filestr<<"Ocm_Mf_Nmr:"<<stCntrMst->Ocm_Mf_Nmr<<", ";
        filestr<<"Ocm_Mf_Dmr:"<<stCntrMst->Ocm_Mf_Dmr<<", ";
        filestr<<"Ocm_Isue_Mtrty_Date:"<<stCntrMst->Ocm_Isue_Mtrty_Date<<", ";
        filestr<<"Ocm_Oi:"<<stCntrMst->Ocm_Oi<<", ";
        filestr<<"Ocm_Oi_Value:"<<stCntrMst->Ocm_Oi_Value<<", ";
        filestr<<"Ocm_Itm_Oi:"<<stCntrMst->Ocm_Itm_Oi<<", ";
        filestr<<"Ocm_Itm_Oi_Value:"<<stCntrMst->Ocm_Itm_Oi_Value<<", ";
        filestr<<"Ocm_Ltp:"<<stCntrMst->Ocm_Ltp<<", ";
        filestr<<"Ocm_Ltp_Chng_Flg:"<<stCntrMst->Ocm_Ltp_Chng_Flg<<", ";
        filestr<<"Ocm_Unrlng_Ltp:"<<stCntrMst->Ocm_Unrlng_Ltp<<", ";
        filestr<<"Ocm_Timer_Unrlng_Ltp:"<<stCntrMst->Ocm_Timer_Unrlng_Ltp<<", ";
        filestr<<"Ocm_Cal_Put_Flg:"<<stCntrMst->Ocm_Cal_Put_Flg<<", ";
        filestr<<"Ocm_Itm_Flg:"<<stCntrMst->Ocm_Itm_Flg<<", ";
        filestr<<"Ocm_Itm_Chng_Flg:"<<stCntrMst->Ocm_Itm_Chng_Flg<<", ";
        filestr<<"Ocm_Oi_Redn_Flg:"<<stCntrMst->Ocm_Oi_Redn_Flg<<", ";
        filestr<<"Ocm_Oi_Chng_Flg:"<<stCntrMst->Ocm_Oi_Chng_Flg<<", ";
        filestr<<"Ocm_Price_Scan_Mlt:"<<stCntrMst->Ocm_Price_Scan_Mlt<<", ";
        filestr<<"Ocm_Psr:"<<stCntrMst->Ocm_Psr<<", ";
        filestr<<"Ocm_Vsr:"<<stCntrMst->Ocm_Vsr<<", ";
        filestr<<"Ocm_Max_Risk_Val:"<<stCntrMst->Ocm_Max_Risk_Val<<", ";
        filestr<<"Ocm_Wtd_Avg_Dlta:"<<stCntrMst->Ocm_Wtd_Avg_Dlta<<", ";
        filestr<<"Ocm_Stlmnt_Prce:"<<stCntrMst->Ocm_Stlmnt_Prce<<", ";
        filestr<<"Ocm_Prev_Stlmnt_Prce:"<<stCntrMst->Ocm_Prev_Stlmnt_Prce<<", ";
        filestr<<"Ocm_Timer_Ltp:"<<stCntrMst->Ocm_Timer_Ltp<<", ";
        filestr<<"Ocm_Im_Wtg:"<<stCntrMst->Ocm_Im_Wtg<<", ";
        filestr<<"Ocm_Weight:"<<stCntrMst->Ocm_Weight<<", ";
        filestr<<"Ocm_Vlty:"<<stCntrMst->Ocm_Vlty<<", ";
        filestr<<"Ocm_Fut_Vlt:"<<stCntrMst->Ocm_Fut_Vlt<<", ";
        filestr<<"Ocm_Fut_Base_Vlt:"<<stCntrMst->Ocm_Fut_Base_Vlt<<", ";
        filestr<<"Ocm_SomChrg:"<<stCntrMst->Ocm_SomChrg<<", ";
        filestr<<"Ocm_Sgm_Mlt:"<<stCntrMst->Ocm_Sgm_Mlt<<", ";
        filestr<<"Ocm_Lkahd_Dys_Psr:"<<stCntrMst->Ocm_Lkahd_Dys_Psr<<", ";
        filestr<<"Ocm_Min_Init_Prcntg:"<<stCntrMst->Ocm_Min_Init_Prcntg<<", ";
        filestr<<"Ocm_Wrk_Days_To_Exp:"<<stCntrMst->Ocm_Wrk_Days_To_Exp<<", ";
        filestr<<"Ocm_Act_Days_To_Exp:"<<stCntrMst->Ocm_Act_Days_To_Exp<<", ";
        filestr<<"Ocm_Days_To_Tndr_Dt:"<<stCntrMst->Ocm_Days_To_Tndr_Dt<<", ";
        filestr<<"Ocm_Tier:"<<stCntrMst->Ocm_Tier<<", ";
        filestr<<"Ocm_Mnth_Id:"<<stCntrMst->Ocm_Mnth_Id<<", ";
        filestr<<"Ocm_Oi_Lmt_Appl:"<<stCntrMst->Ocm_Oi_Lmt_Appl<<", ";
        filestr<<"Ocd_Clnt_Oi_Lmt:"<<stCntrMst->Ocd_Clnt_Oi_Lmt<<", ";
        filestr<<"Ocd_Clnt_Oi_Prcntg:"<<stCntrMst->Ocd_Clnt_Oi_Prcntg<<", ";
        filestr<<"Ocd_Clnt_Oi_Vle:"<<stCntrMst->Ocd_Clnt_Oi_Vle<<", ";
        filestr<<"Ocd_Mbr_Oi_Lmt:"<<stCntrMst->Ocd_Mbr_Oi_Lmt<<", ";
        filestr<<"Ocd_Mbr_Oi_Prcntg:"<<stCntrMst->Ocd_Mbr_Oi_Prcntg<<", ";
        filestr<<"Ocd_Mbr_Oi_Vle:"<<stCntrMst->Ocd_Mbr_Oi_Vle<<", ";
        filestr<<"Ocd_Cntr_Oi_Lmt:"<<stCntrMst->Ocd_Cntr_Oi_Lmt<<", ";
        filestr<<"Ocd_Cntr_Oi_Prcntg:"<<stCntrMst->Ocd_Cntr_Oi_Prcntg<<", ";
        filestr<<"Ocd_Cntr_Oi_Vle:"<<stCntrMst->Ocd_Cntr_Oi_Vle<<", ";
        filestr<<"Ocm_AM_Adhc_flg:"<<stCntrMst->Ocm_AM_Adhc_flg<<", ";
        filestr<<"Ocm_AM_Clnt_Oi_Prcntg:"<<stCntrMst->Ocm_AM_Clnt_Oi_Prcntg<<", ";
        filestr<<"Ocm_AM_Clnt_Oi_Vle:"<<stCntrMst->Ocm_AM_Clnt_Oi_Vle<<", ";
        filestr<<"Ocm_AM_Clnt_Oi_Prcntg_Mrgn:"<<stCntrMst->Ocm_AM_Clnt_Oi_Prcntg_Mrgn<<", ";
        filestr<<"Ocm_AM_Clnt_Oi_Vle_Mrgn:"<<stCntrMst->Ocm_AM_Clnt_Oi_Vle_Mrgn<<", ";
        filestr<<"Ocm_AM_Pstn_typ:"<<stCntrMst->Ocm_AM_Pstn_typ<<", ";
        filestr<<"Ocm_Alrt_Prctn_Sent:"<<stCntrMst->Ocm_Alrt_Prctn_Sent<<", ";
        filestr<<"Ocm_Undrcnl_Mrgn_Prcntg:"<<stCntrMst->Ocm_Undrcnl_Mrgn_Prcntg<<", ";
        filestr<<"Ocm_Lng_Adhc_Mrgn_Prcntg:"<<stCntrMst->Ocm_Lng_Adhc_Mrgn_Prcntg<<", ";
        filestr<<"Ocm_Shrt_Adhc_Mrgn_Prcntg:"<<stCntrMst->Ocm_Shrt_Adhc_Mrgn_Prcntg<<", ";
        filestr<<"Ocm_Mrgn_Side_Flg:"<<stCntrMst->Ocm_Mrgn_Side_Flg<<", ";
        filestr<<"Ocm_Undrcnl_Mrgn_Flg:"<<stCntrMst->Ocm_Undrcnl_Mrgn_Flg<<", ";
		filestr<<"Ocm_Eff_Lng_Pe_Mrgn_Prcntg:"<<stCntrMst->Ocm_Eff_Lng_Pe_Mrgn_Prcntg<<", "; //PRE-EXP REDESIGN 10FEB2011
		filestr<<"Ocm_Eff_Shrt_Pe_Mrgn_Prcntg:"<<stCntrMst->Ocm_Eff_Shrt_Pe_Mrgn_Prcntg<<", ";//PRE-EXP REDESIGN 10FEB2011
		filestr<<"Ocm_IMC_Perc:"<<stCntrMst->Ocm_IMC_Perc<<", ";   //SHRAMIK:CR04501 - Added for IMC Multiplier
		filestr<<"Ocm_El_Mrgn_Prcntg:"<<stCntrMst->Ocm_El_Mrgn_Prcntg;  //SHRAMIK:CR04502 - Added for ELM Multiplier
		
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 5 times in multimap so Net Total Size:"<<MapSize*5;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_ClrMbrCntrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;
	struct StClrMbrCntr *ObjStClrMbrCntr = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        ObjStClrMbrCntr= (struct StClrMbrCntr*)(*ObjMultiMapIterator).second;

        filestr<<"Ocmc_Cmbr_Id:"<<ObjStClrMbrCntr->Ocmc_Cmbr_Id<<", ";
        filestr<<"Ocmc_Tokn_Nm:"<<ObjStClrMbrCntr->Ocmc_Tokn_Nm<<", ";
        filestr<<"Ocmc_Long_Oi:"<<ObjStClrMbrCntr->Ocmc_Long_Oi<<", ";
        filestr<<"Ocmc_Shrt_Oi:"<<ObjStClrMbrCntr->Ocmc_Shrt_Oi<<", ";
        filestr<<"Ocmc_Long_Oi_Value:"<<ObjStClrMbrCntr->Ocmc_Long_Oi_Value<<", ";
        filestr<<"Ocmc_Shrt_Oi_Value:"<<ObjStClrMbrCntr->Ocmc_Shrt_Oi_Value;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_MbrClntMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct  StMbrClntMstr   *MbrClntMstrMmryObj = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;
    
        MbrClntMstrMmryObj= (struct StMbrClntMstr*)(*ObjMultiMapIterator).second;

        filestr<<"Omcm_Cmbr_Id:"<<MbrClntMstrMmryObj->Omcm_Cmbr_Id<<", ";
        filestr<<"Omcm_Tmbr_Id:"<<MbrClntMstrMmryObj->Omcm_Tmbr_Id<<", ";
        filestr<<"Omcm_Clnt_Id:"<<MbrClntMstrMmryObj->Omcm_Clnt_Id<<", ";
        filestr<<"Omcm_Pro_Cli_Flg:"<<MbrClntMstrMmryObj->Omcm_Pro_Cli_Flg<<", ";
        filestr<<"Omcm_Init_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Init_Mrgn<<", ";
        filestr<<"Omcm_Init_Mrgn_les_NBP:"<<MbrClntMstrMmryObj->Omcm_Init_Mrgn_les_NBP<<", ";
        filestr<<"Omcm_NBP:"<<MbrClntMstrMmryObj->Omcm_NBP<<", ";
        filestr<<"Omcm_Exp_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Exp_Mrgn<<", ";
		filestr<<"Omcm_EL_Mrgn:"<<MbrClntMstrMmryObj->Omcm_EL_Mrgn<<", ";      //SHRAMIK:CR04502 - Added for ELM
        filestr<<"Omcm_Pre_Exp_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Pre_Exp_Mrgn<<", ";
        filestr<<"Omcm_Adhc_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Adhc_Mrgn<<", ";
        filestr<<"Omcm_Mtm_Pl:"<<MbrClntMstrMmryObj->Omcm_Mtm_Pl<<", ";
        filestr<<"Omcm_Dlvry_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Dlvry_Mrgn<<", ";
        filestr<<"Omcm_Undrctnl_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Undrctnl_Mrgn<<", ";
        filestr<<"Omcm_Conc_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Conc_Mrgn<<", ";
		filestr<<"Omcm_Exp_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Exp_Mrgn<<", ";
		filestr<<"Omcm_Cash_Mrgn:"<<MbrClntMstrMmryObj->Omcm_Cash_Mrgn<<", "; //CR06275: Arushi Added
		filestr<<"Omcm_MTM_Crystallized:"<<MbrClntMstrMmryObj->Omcm_MTM_Crystallized<<", "; //CR06275: Arushi Added
		filestr<<"Omcm_Prev_MTM_Crystallized:"<<MbrClntMstrMmryObj->Omcm_Prev_MTM_Crystallized<<", "; //CR06275: Arushi Added
		filestr<<"Omcm_Pre_Exp_Mrgn_Optn:"<<MbrClntMstrMmryObj->Omcm_Pre_Exp_Mrgn_Optn;	//CR06275_Bug:Arushi added
		filestr<<"Omcm_Collateral:"<<MbrClntMstrMmryObj->Omcm_Collateral;		//CR06489 : Pritpal : 
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}


int MultiMapMngr :: Write_MbrClntUndrLngTier(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StMbrClntUndrLngTier *ObjStMbrClntUndrLngTier = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        ObjStMbrClntUndrLngTier= (struct StMbrClntUndrLngTier*)(*ObjMultiMapIterator).second;

        filestr<<"Omcut_Cmbr_Id:"<<ObjStMbrClntUndrLngTier->Omcut_Cmbr_Id<<", ";
        filestr<<"Omcut_Tmbr_Id:"<<ObjStMbrClntUndrLngTier->Omcut_Tmbr_Id<<", ";
        filestr<<"Omcut_Clnt_Id:"<<ObjStMbrClntUndrLngTier->Omcut_Clnt_Id<<", ";
        filestr<<"Omcut_Pro_Cli_Flg:"<<ObjStMbrClntUndrLngTier->Omcut_Pro_Cli_Flg<<", ";
        filestr<<"Omcut_Smbl:"<<ObjStMbrClntUndrLngTier->Omcut_Smbl<<", ";
        filestr<<"Omcut_Tier:"<<ObjStMbrClntUndrLngTier->Omcut_Tier<<", ";
        filestr<<"Omcut_Max_Rsk_Val:"<<ObjStMbrClntUndrLngTier->Omcut_Max_Rsk_Val<<", ";
        filestr<<"Omcut_Pstv_Net_Dlta:"<<ObjStMbrClntUndrLngTier->Omcut_Pstv_Net_Dlta<<", ";
        filestr<<"Omcut_Ngtv_Net_Dlta:"<<ObjStMbrClntUndrLngTier->Omcut_Ngtv_Net_Dlta<<", ";
        filestr<<"Omcut_Pstv_Icc_Net_Dlta:"<<ObjStMbrClntUndrLngTier->Omcut_Pstv_Icc_Net_Dlta<<", ";
        filestr<<"Omcut_Ngtv_Icc_Net_Dlta:"<<ObjStMbrClntUndrLngTier->Omcut_Ngtv_Icc_Net_Dlta<<", ";
        filestr<<"Omcut_Pstv_ICC_Spread:"<<ObjStMbrClntUndrLngTier->Omcut_Pstv_ICC_Spread<<", ";
        filestr<<"Omcut_Ngtv_ICC_Spread:"<<ObjStMbrClntUndrLngTier->Omcut_Ngtv_ICC_Spread<<", ";
        filestr<<"Omcut_Pstv_IM_Spread:"<<ObjStMbrClntUndrLngTier->Omcut_Pstv_IM_Spread<<", ";
        filestr<<"Omcut_Ngtv_IM_Spread:"<<ObjStMbrClntUndrLngTier->Omcut_Ngtv_IM_Spread<<", ";
        filestr<<"Omcut_Pstv_EM_Spread:"<<ObjStMbrClntUndrLngTier->Omcut_Pstv_EM_Spread<<", ";
        filestr<<"Omcut_Ngtv_EM_Spread:"<<ObjStMbrClntUndrLngTier->Omcut_Ngtv_EM_Spread<<", ";
        filestr<<"Omcut_Pstv_NonSprd_AVL:"<<ObjStMbrClntUndrLngTier->Omcut_Pstv_NonSprd_AVL<<", ";
        filestr<<"Omcut_Ngtv_NonSprd_AVL:"<<ObjStMbrClntUndrLngTier->Omcut_Ngtv_NonSprd_AVL<<", ";
        filestr<<"Omcut_Ngtv_NonSprd_NA:"<<ObjStMbrClntUndrLngTier->Omcut_Ngtv_NonSprd_NA<<", ";
        filestr<<"Omcut_Pstv_NonSprd_NA:"<<ObjStMbrClntUndrLngTier->Omcut_Pstv_NonSprd_NA<<", ";
        filestr<<"Omcut_Peep_Pstv_Net_Dlta:"<<ObjStMbrClntUndrLngTier->Omcut_Peep_Pstv_Net_Dlta<<", ";
        filestr<<"Omcut_Peep_Ngtv_Net_Dlta:"<<ObjStMbrClntUndrLngTier->Omcut_Peep_Ngtv_Net_Dlta<<", ";
        filestr<<"Omcut_Peep_Pstv_NonSprd_AVL:"<<ObjStMbrClntUndrLngTier->Omcut_Peep_Pstv_NonSprd_AVL<<", ";
        filestr<<"Omcut_Peep_Ngtv_NonSprd_AVL:"<<ObjStMbrClntUndrLngTier->Omcut_Peep_Ngtv_NonSprd_AVL<<", ";
        filestr<<"Omcut_Peep_Ngtv_NonSprd_NA:"<<ObjStMbrClntUndrLngTier->Omcut_Peep_Ngtv_NonSprd_NA<<", ";
        filestr<<"Omcut_Peep_Pstv_NonSprd_NA:"<<ObjStMbrClntUndrLngTier->Omcut_Peep_Pstv_NonSprd_NA;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 5 times in multimap so Net Total Size:"<<MapSize*5;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_UsrClntUndrLngTier(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StUsrClntUndrLngTier *ObjStUsrClntUndrLngTier = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        ObjStUsrClntUndrLngTier= (struct StUsrClntUndrLngTier*)(*ObjMultiMapIterator).second;

        filestr<<"Oucut_Cmbr_Id:"<<ObjStUsrClntUndrLngTier->Oucut_Cmbr_Id<<", ";
        filestr<<"Oucut_Tmbr_Id:"<<ObjStUsrClntUndrLngTier->Oucut_Tmbr_Id<<", ";
        filestr<<"Oucut_Tusr_Id:"<<ObjStUsrClntUndrLngTier->Oucut_Tusr_Id<<", ";
        filestr<<"Oucut_Clnt_Id:"<<ObjStUsrClntUndrLngTier->Oucut_Clnt_Id<<", ";
        filestr<<"Oucut_Pro_Cli_Flg:"<<ObjStUsrClntUndrLngTier->Oucut_Pro_Cli_Flg<<", ";
        filestr<<"Oucut_Smbl:"<<ObjStUsrClntUndrLngTier->Oucut_Smbl<<", ";
        filestr<<"Oucut_Tier:"<<ObjStUsrClntUndrLngTier->Oucut_Tier<<", ";
        filestr<<"Oucut_Max_Rsk_Val:"<<ObjStUsrClntUndrLngTier->Oucut_Max_Rsk_Val<<", ";
        filestr<<"Oucut_Pstv_Net_Dlta:"<<ObjStUsrClntUndrLngTier->Oucut_Pstv_Net_Dlta<<", ";
        filestr<<"Oucut_Ngtv_Net_Dlta:"<<ObjStUsrClntUndrLngTier->Oucut_Ngtv_Net_Dlta<<", ";
        filestr<<"Oucut_Pstv_Icc_Net_Dlta:"<<ObjStUsrClntUndrLngTier->Oucut_Pstv_Icc_Net_Dlta<<", ";
        filestr<<"Oucut_Ngtv_Icc_Net_Dlta:"<<ObjStUsrClntUndrLngTier->Oucut_Ngtv_Icc_Net_Dlta<<", ";
        filestr<<"Oucut_Pstv_ICC_Spread:"<<ObjStUsrClntUndrLngTier->Oucut_Pstv_ICC_Spread<<", ";
        filestr<<"Oucut_Ngtv_ICC_Spread:"<<ObjStUsrClntUndrLngTier->Oucut_Ngtv_ICC_Spread<<", ";
        filestr<<"Oucut_Pstv_IM_Spread:"<<ObjStUsrClntUndrLngTier->Oucut_Pstv_IM_Spread<<", ";
        filestr<<"Oucut_Ngtv_IM_Spread:"<<ObjStUsrClntUndrLngTier->Oucut_Ngtv_IM_Spread<<", ";
        filestr<<"Oucut_Pstv_EM_Spread:"<<ObjStUsrClntUndrLngTier->Oucut_Pstv_EM_Spread<<", ";
        filestr<<"Oucut_Ngtv_EM_Spread:"<<ObjStUsrClntUndrLngTier->Oucut_Ngtv_EM_Spread<<", ";
        filestr<<"Oucut_Pstv_NonSprd_AVL:"<<ObjStUsrClntUndrLngTier->Oucut_Pstv_NonSprd_AVL<<", ";
        filestr<<"Oucut_Ngtv_NonSprd_AVL:"<<ObjStUsrClntUndrLngTier->Oucut_Ngtv_NonSprd_AVL<<", ";
        filestr<<"Oucut_Ngtv_NonSprd_NA:"<<ObjStUsrClntUndrLngTier->Oucut_Ngtv_NonSprd_NA<<", ";
        filestr<<"Oucut_Pstv_NonSprd_NA:"<<ObjStUsrClntUndrLngTier->Oucut_Pstv_NonSprd_NA<<", ";
        filestr<<"Oucut_Peep_Pstv_Net_Dlta:"<<ObjStUsrClntUndrLngTier->Oucut_Peep_Pstv_Net_Dlta<<", ";
        filestr<<"Oucut_Peep_Ngtv_Net_Dlta:"<<ObjStUsrClntUndrLngTier->Oucut_Peep_Ngtv_Net_Dlta<<", ";
        filestr<<"Oucut_Peep_Pstv_NonSprd_AVL:"<<ObjStUsrClntUndrLngTier->Oucut_Peep_Pstv_NonSprd_AVL<<", ";
        filestr<<"Oucut_Peep_Ngtv_NonSprd_AVL:"<<ObjStUsrClntUndrLngTier->Oucut_Peep_Ngtv_NonSprd_AVL<<", ";
        filestr<<"Oucut_Peep_Ngtv_NonSprd_NA:"<<ObjStUsrClntUndrLngTier->Oucut_Peep_Ngtv_NonSprd_NA;
        filestr<<"Oucut_Peep_Pstv_NonSprd_NA:"<<ObjStUsrClntUndrLngTier->Oucut_Peep_Pstv_NonSprd_NA<<", ";
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 3 times in multimap so Net Total Size:"<<MapSize*3;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_UsrClntMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct  StUsrClntMstr   *UsrClntMstrMmryObj = NULL;
	
    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        UsrClntMstrMmryObj= (struct StUsrClntMstr*)(*ObjMultiMapIterator).second;

        filestr<<"Oucm_Clrng_Mbr_Id:"<<UsrClntMstrMmryObj->Oucm_Clrng_Mbr_Id<<", ";
        filestr<<"Oucm_Mbr_Id:"<<UsrClntMstrMmryObj->Oucm_Mbr_Id<<", ";
        filestr<<"Oucm_User_Id:"<<UsrClntMstrMmryObj->Oucm_User_Id<<", ";
        filestr<<"Oucm_Clnt_Id:"<<UsrClntMstrMmryObj->Oucm_Clnt_Id<<", ";
        filestr<<"Oucm_Pro_Cli_Flg:"<<UsrClntMstrMmryObj->Oucm_Pro_Cli_Flg<<", ";
        filestr<<"Oucm_Init_Mrgn:"<<UsrClntMstrMmryObj->Oucm_Init_Mrgn<<", ";
        filestr<<"Oucm_Init_Mrgn_les_NBP:"<<UsrClntMstrMmryObj->Oucm_Init_Mrgn_les_NBP<<", ";
        filestr<<"Oucm_NBP:"<<UsrClntMstrMmryObj->Oucm_NBP<<", ";
        filestr<<"Oucm_Mtm_Pl:"<<UsrClntMstrMmryObj->Oucm_Mtm_Pl<<", ";
        filestr<<"Oucm_Exp_Mrgn:"<<UsrClntMstrMmryObj->Oucm_Exp_Mrgn<<", ";
        filestr<<"Oucm_Pre_Exp_Mrgn:"<<UsrClntMstrMmryObj->Oucm_Pre_Exp_Mrgn<<", ";
        filestr<<"Oucm_Adhc_Mrgn:"<<UsrClntMstrMmryObj->Oucm_Adhc_Mrgn<<", ";
        filestr<<"Oucm_Undrctnl_Mrgn:"<<UsrClntMstrMmryObj->Oucm_Undrctnl_Mrgn<<", ";
		filestr<<"Oucm_EL_Mrgn:"<<UsrClntMstrMmryObj->Oucm_EL_Mrgn;   //SHRAMIK:CR04502 - Added for ELM
		filestr<<"Oucm_Net_Buy_Premium:"<<UsrClntMstrMmryObj->Oucm_NBP;	//Suhas: added: CR04897: NBP
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_ExpContractMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StExpCntrMst  *stExpCntrMst = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        stExpCntrMst= (struct StExpCntrMst*)(*ObjMultiMapIterator).second;

        filestr<<"Oecm_Tokn_Nm:"<<stExpCntrMst->Oecm_Tokn_Nm<<", ";
        filestr<<"Oecm_Smbl:"<<stExpCntrMst->Oecm_Smbl<<", ";
        filestr<<"Oecm_Undrlng_Tokn_Nm:"<<stExpCntrMst->Oecm_Undrlng_Tokn_Nm<<", ";
        filestr<<"Oecm_Mf_Nmr:"<<stExpCntrMst->Oecm_Mf_Nmr<<", ";
        filestr<<"Oecm_Mf_Dmr:"<<stExpCntrMst->Oecm_Mf_Dmr<<", ";
        filestr<<"Oecm_Isue_Mtrty_Date:"<<stExpCntrMst->Oecm_Isue_Mtrty_Date<<", ";
        filestr<<"Oecm_Fsp:"<<stExpCntrMst->Oecm_Fsp<<", ";
		//filestr<<"Oecm_min_dlvr_mnth_chrg:"<<stExpCntrMst->Oecm_min_dlvr_mnth_chrg;  	
		//CR02087 : start: To seperate Min Dlv Month Charge for Buy and Sell
        filestr<<"Oecm_min_dlvr_mnth_chrg_lng:"<<stExpCntrMst->Oecm_min_dlvr_mnth_chrg_lng;  	
        filestr<<"Oecm_min_dlvr_mnth_chrg_shrt:"<<stExpCntrMst->Oecm_min_dlvr_mnth_chrg_shrt;  	
		//CR02087 : end: To seperate Min Dlv Month Charge for Buy and Sell
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_UsrClntUndrLngMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StUsrClntUndrlng  *stUsrClntUndrlngObj = NULL;
    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        stUsrClntUndrlngObj= (struct StUsrClntUndrlng*)(*ObjMultiMapIterator).second;

        filestr<<"Oucu_Cmbr_Id:"<<stUsrClntUndrlngObj->Oucu_Cmbr_Id<<", ";
        filestr<<"Oucu_Tmbr_Id:"<<stUsrClntUndrlngObj->Oucu_Tmbr_Id<<", ";
        filestr<<"Oucu_User_Id:"<<stUsrClntUndrlngObj->Oucu_User_Id<<", ";
        filestr<<"Oucu_Clnt_Id:"<<stUsrClntUndrlngObj->Oucu_Clnt_Id<<", ";
        filestr<<"Oucu_Pro_Cli_Flg:"<<stUsrClntUndrlngObj->Oucu_Pro_Cli_Flg<<", ";
        filestr<<"Oucu_Smbl:"<<stUsrClntUndrlngObj->Oucu_Smbl<<", ";
        filestr<<"Oucu_Exp_Margin:"<<stUsrClntUndrlngObj->Oucu_Exp_Margin<<", ";
        filestr<<"Oucu_Pre_Exp_Margin:"<<stUsrClntUndrlngObj->Oucu_Pre_Exp_Margin<<", ";
        filestr<<"Oucu_Init_Mrgn:"<<stUsrClntUndrlngObj->Oucu_Init_Mrgn<<", ";
        filestr<<"Oucu_Scan_Risk:"<<stUsrClntUndrlngObj->Oucu_Scan_Risk<<", ";
        filestr<<"Oucu_Prce_Risk:"<<stUsrClntUndrlngObj->Oucu_Prce_Risk<<", ";
        filestr<<"Oucu_Net_Dlt:"<<stUsrClntUndrlngObj->Oucu_Net_Dlt<<", ";
        filestr<<"Oucu_Imc:"<<stUsrClntUndrlngObj->Oucu_Imc<<", ";
        filestr<<"Oucu_Icc:"<<stUsrClntUndrlngObj->Oucu_Icc<<", ";
        filestr<<"Oucu_Shrt_Opt_Min_Chrg:"<<stUsrClntUndrlngObj->Oucu_Shrt_Opt_Min_Chrg<<", ";
        filestr<<"Oucu_Net_Opt_Val:"<<stUsrClntUndrlngObj->Oucu_Net_Opt_Val<<", ";
        filestr<<"Oucu_Net_Buy_Prem:"<<stUsrClntUndrlngObj->Oucu_Net_Buy_Prem<<", ";
        filestr<<"Oucu_Adhoc_Mrgn:"<<stUsrClntUndrlngObj->Oucu_Adhoc_Mrgn<<", ";
        filestr<<"Oucu_Undrctnl_Mrgn:"<<stUsrClntUndrlngObj->Oucu_Undrctnl_Mrgn<<", ";
		filestr<<"Oucu_EL_Margin:"<<stUsrClntUndrlngObj->Oucu_EL_Margin;           //SHRAMIK:CR04502 - Added for ELM
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}


int MultiMapMngr :: Write_TrdMbrUndrLngMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StMbrUndrLng *objStMbrUndrLng = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        objStMbrUndrLng= (struct StMbrUndrLng*)(*ObjMultiMapIterator).second;

        filestr<<"Omu_Cmbr_Id:"<<objStMbrUndrLng->Omu_Cmbr_Id<<", ";
        filestr<<"Omu_Tmbr_Id:"<<objStMbrUndrLng->Omu_Tmbr_Id<<", ";
        filestr<<"Omu_Smbl:"<<objStMbrUndrLng->Omu_Smbl<<", ";
        filestr<<"Omu_Hdg_Clnt_Flg:"<<objStMbrUndrLng->Omu_Hdg_Clnt_Flg<<", ";
        filestr<<"Omu_Undrlng_Tokn_Nm:"<<objStMbrUndrLng->Omu_Undrlng_Tokn_Nm<<", ";
        filestr<<"Omu_Dlvry_Mrgn:"<<objStMbrUndrLng->Omu_Dlvry_Mrgn<<", ";
        filestr<<"Omu_Fut_Long_Oi:"<<objStMbrUndrLng->Omu_Fut_Long_Oi<<", ";
        filestr<<"Omu_Fut_Long_Oi_Value:"<<objStMbrUndrLng->Omu_Fut_Long_Oi_Value<<", ";
        filestr<<"Omu_Fut_Shrt_Oi:"<<objStMbrUndrLng->Omu_Fut_Shrt_Oi<<", ";
        filestr<<"Omu_Fut_Shrt_Oi_Value:"<<objStMbrUndrLng->Omu_Fut_Shrt_Oi_Value<<", ";
        filestr<<"Omu_Fut_Alrt_Prctn_Sent:"<<objStMbrUndrLng->Omu_Fut_Alrt_Prctn_Sent<<", ";
        filestr<<"Omu_Opt_Alrt_Prctn_Sent:"<<objStMbrUndrLng->Omu_Opt_Alrt_Prctn_Sent<<", ";		//CR04897 : Pritpal : added : 
        filestr<<"Omu_Hdg_Alrt_Prctn_Sent:"<<objStMbrUndrLng->Omu_Hdg_Alrt_Prctn_Sent<<", ";
        filestr<<"Omu_Itm_Long_Oi:"<<objStMbrUndrLng->Omu_Itm_Long_Oi<<", ";
        filestr<<"Omu_Itm_Short_Oi:"<<objStMbrUndrLng->Omu_Itm_Short_Oi<<", ";
        filestr<<"Omu_Itm_Long_Oi_Value:"<<objStMbrUndrLng->Omu_Itm_Long_Oi_Value<<", ";
        filestr<<"Omu_Itm_Short_Oi_Value:"<<objStMbrUndrLng->Omu_Itm_Short_Oi_Value<<", ";
        filestr<<"Omu_Conc_Mrgn:"<<objStMbrUndrLng->Omu_Conc_Mrgn;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}


int MultiMapMngr :: Write_ClrMbrUndrLngMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;


	struct StClrMbrUndrLng *objStClrMbrUndrLng = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        objStClrMbrUndrLng= (struct StClrMbrUndrLng*)(*ObjMultiMapIterator).second;

        filestr<<"Omu_Cmbr_Id:"<<objStClrMbrUndrLng->Omu_Cmbr_Id<<", ";
        filestr<<"Omu_Smbl:"<<objStClrMbrUndrLng->Omu_Smbl<<", ";
        filestr<<"Omu_Undrlng_Tokn_Nm:"<<objStClrMbrUndrLng->Omu_Undrlng_Tokn_Nm;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 2 times in multimap so Net Total Size:"<<MapSize*2;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_TrdMbrCntrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StMbrCntr *StMbrCntrobj = NULL;	

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        StMbrCntrobj= (struct StMbrCntr*)(*ObjMultiMapIterator).second;

        filestr<<"Omc_Cmbr_Id:"<<StMbrCntrobj->Omc_Cmbr_Id<<", ";
        filestr<<"Omc_Tmbr_Id:"<<StMbrCntrobj->Omc_Tmbr_Id<<", ";
        filestr<<"Omc_Tokn_Nm:"<<StMbrCntrobj->Omc_Tokn_Nm<<", ";
        filestr<<"Omc_Und_Tokn_Nm:"<<StMbrCntrobj->Omc_Und_Tokn_Nm<<", ";
        filestr<<"Omc_Smbl:"<<StMbrCntrobj->Omc_Smbl<<", ";
        filestr<<"Omc_Long_Oi:"<<StMbrCntrobj->Omc_Long_Oi<<", ";
        filestr<<"Omc_Shrt_Oi:"<<StMbrCntrobj->Omc_Shrt_Oi<<", ";
        filestr<<"Omc_Long_Oi_Value:"<<StMbrCntrobj->Omc_Long_Oi_Value<<", ";
        filestr<<"Omc_Shrt_Oi_Value:"<<StMbrCntrobj->Omc_Shrt_Oi_Value<<", ";
        filestr<<"Omc_Alrt_Prctn_Sent:"<<StMbrCntrobj->Omc_Alrt_Prctn_Sent<<", ";
        filestr<<"Omc_Conc_Mrgn:"<<StMbrCntrobj->Omc_Conc_Mrgn<<", ";
        filestr<<"Omc_Adhoc_Mrgn:"<<StMbrCntrobj->Omc_Adhoc_Mrgn;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 4 times in multimap so Net Total Size:"<<MapSize*4;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_MbrClntUndrLngMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StMbrClntUndrLng  *ObjstMbrClntSmbl = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        ObjstMbrClntSmbl= (struct StMbrClntUndrLng*)(*ObjMultiMapIterator).second;

        filestr<<"Omcu_Cmbr_Id:"<<ObjstMbrClntSmbl->Omcu_Cmbr_Id<<", ";
        filestr<<"Omcu_Tmbr_Id:"<<ObjstMbrClntSmbl->Omcu_Tmbr_Id<<", ";
        filestr<<"Omcu_Clnt_Id:"<<ObjstMbrClntSmbl->Omcu_Clnt_Id<<", ";
        filestr<<"Omcu_Pro_Cli_Flg:"<<ObjstMbrClntSmbl->Omcu_Pro_Cli_Flg<<", ";
        filestr<<"Omcu_Smbl:"<<ObjstMbrClntSmbl->Omcu_Smbl<<", ";
        filestr<<"Omcu_Hdg_Clnt_Flg:"<<ObjstMbrClntSmbl->Omcu_Hdg_Clnt_Flg<<", ";
        filestr<<"Omcu_Fut_Long_Oi:"<<ObjstMbrClntSmbl->Omcu_Fut_Long_Oi<<", ";
        filestr<<"Omcu_Fut_Long_Oi_Val:"<<ObjstMbrClntSmbl->Omcu_Fut_Long_Oi_Val<<", ";
        filestr<<"Omcu_Fut_Shrt_Oi:"<<ObjstMbrClntSmbl->Omcu_Fut_Shrt_Oi<<", ";
        filestr<<"Omcu_Fut_Shrt_Oi_Val:"<<ObjstMbrClntSmbl->Omcu_Fut_Shrt_Oi_Val<<", ";
        filestr<<"Omcu_Fut_Net_Oi:"<<ObjstMbrClntSmbl->Omcu_Fut_Net_Oi<<", ";
        filestr<<"Omcu_Fut_Net_Oi_Val:"<<ObjstMbrClntSmbl->Omcu_Fut_Net_Oi_Val<<", ";
        filestr<<"Omcu_Itm_Long_Oi:"<<ObjstMbrClntSmbl->Omcu_Itm_Long_Oi<<", ";
        filestr<<"Omcu_Itm_Short_Oi:"<<ObjstMbrClntSmbl->Omcu_Itm_Short_Oi<<", ";
        filestr<<"Omcu_Itm_Long_Oi_Val:"<<ObjstMbrClntSmbl->Omcu_Itm_Long_Oi_Val<<", ";
        filestr<<"Omcu_Itm_Short_Oi_Val:"<<ObjstMbrClntSmbl->Omcu_Itm_Short_Oi_Val<<", ";
        filestr<<"Omcu_Undrlng_Tokn_Nm:"<<ObjstMbrClntSmbl->Omcu_Undrlng_Tokn_Nm<<", ";
        filestr<<"Omcu_Exp_Margin:"<<ObjstMbrClntSmbl->Omcu_Exp_Margin<<", ";
        filestr<<"Omcu_Pre_Exp_Margin:"<<ObjstMbrClntSmbl->Omcu_Pre_Exp_Margin<<", ";
        filestr<<"Omcu_Init_Mrgn:"<<ObjstMbrClntSmbl->Omcu_Init_Mrgn<<", ";
        filestr<<"Omcu_Dlvry_Mrgn:"<<ObjstMbrClntSmbl->Omcu_Dlvry_Mrgn<<", ";
        filestr<<"Omcu_Prce_Risk:"<<ObjstMbrClntSmbl->Omcu_Prce_Risk<<", ";
        filestr<<"Omcu_Scan_Risk:"<<ObjstMbrClntSmbl->Omcu_Scan_Risk<<", ";
        filestr<<"Omcu_Net_Dlt:"<<ObjstMbrClntSmbl->Omcu_Net_Dlt<<", ";
        filestr<<"Omcu_Imc:"<<ObjstMbrClntSmbl->Omcu_Imc<<", ";
        filestr<<"Omcu_Icc:"<<ObjstMbrClntSmbl->Omcu_Icc<<", ";
        filestr<<"Omcu_Shrt_Opt_Min_Chrg:"<<ObjstMbrClntSmbl->Omcu_Shrt_Opt_Min_Chrg<<", ";
        filestr<<"Omcu_Shrt_Opt_Min_Val:"<<ObjstMbrClntSmbl->Omcu_Shrt_Opt_Min_Val<<", ";
        filestr<<"Omcu_Net_Opt_Val:"<<ObjstMbrClntSmbl->Omcu_Net_Opt_Val<<", ";
        filestr<<"Omcu_Net_Buy_Prem:"<<ObjstMbrClntSmbl->Omcu_Net_Buy_Prem<<", ";
        filestr<<"Omcu_Fut_Alrt_Prctn_Sent:"<<ObjstMbrClntSmbl->Omcu_Fut_Alrt_Prctn_Sent<<", ";
        filestr<<"Omcu_Option_Alrt_Prctn_Sent:"<<ObjstMbrClntSmbl->Omcu_Option_Alrt_Prctn_Sent<<", ";
        filestr<<"Omcu_Opt_Alrt_Prctn_Sent:"<<ObjstMbrClntSmbl->Omcu_Opt_Alrt_Prctn_Sent<<", ";
        filestr<<"Omcu_Conc_Mrgn:"<<ObjstMbrClntSmbl->Omcu_Conc_Mrgn<<", ";
        filestr<<"Omcu_Adhoc_Mrgn:"<<ObjstMbrClntSmbl->Omcu_Adhoc_Mrgn<<", ";
        filestr<<"Omcu_Undrctnl_Mrgn:"<<ObjstMbrClntSmbl->Omcu_Undrctnl_Mrgn<<", ";
		filestr<<"Omcu_EL_Margin:"<<ObjstMbrClntSmbl->Omcu_EL_Margin;     //SHRAMIK:CR04502 - Added for ELM
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 4 times in multimap so Net Total Size:"<<MapSize*4;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_MbrClntCntrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StMbrClntCntr* MbrClntCntrMmryObj = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        MbrClntCntrMmryObj= (struct StMbrClntCntr*)(*ObjMultiMapIterator).second;

        filestr<<"Omcc_Cmbr_Id:"<<MbrClntCntrMmryObj->Omcc_Cmbr_Id<<", ";
        filestr<<"Omcc_Tmbr_Id:"<<MbrClntCntrMmryObj->Omcc_Tmbr_Id<<", ";
        filestr<<"Omcc_Clnt_Id:"<<MbrClntCntrMmryObj->Omcc_Clnt_Id<<", ";
        filestr<<"Omcc_Pro_Cli_Flg:"<<MbrClntCntrMmryObj->Omcc_Pro_Cli_Flg<<", ";
        filestr<<"Omcc_Tokn_Nm:"<<MbrClntCntrMmryObj->Omcc_Tokn_Nm<<", ";
        filestr<<"Omcc_Fut_Opt_Flg:"<<MbrClntCntrMmryObj->Omcc_Fut_Opt_Flg<<", ";
        filestr<<"Omcc_Mnth_Id:"<<MbrClntCntrMmryObj->Omcc_Mnth_Id<<", ";
        filestr<<"Omcc_Undrlng_Tokn_Nm:"<<MbrClntCntrMmryObj->Omcc_Undrlng_Tokn_Nm<<", ";
        filestr<<"Omcc_Smbl:"<<MbrClntCntrMmryObj->Omcc_Smbl<<", ";
        filestr<<"Omcc_Exp_Dt:"<<MbrClntCntrMmryObj->Omcc_Exp_Dt<<", ";
        filestr<<"Omcc_Mtm_Pl:"<<MbrClntCntrMmryObj->Omcc_Mtm_Pl<<", ";
        filestr<<"Omcc_Oi:"<<MbrClntCntrMmryObj->Omcc_Oi<<", ";
        filestr<<"Omcc_Oi_Value:"<<MbrClntCntrMmryObj->Omcc_Oi_Value<<", ";
        filestr<<"Omcc_Itm_Oi:"<<MbrClntCntrMmryObj->Omcc_Itm_Oi<<", ";
        filestr<<"Omcc_Itm_Oi_Value:"<<MbrClntCntrMmryObj->Omcc_Itm_Oi_Value<<", ";
        filestr<<"Omcc_Days_Long_OI_value:"<<MbrClntCntrMmryObj->Omcc_Days_Long_OI_value<<", ";
        filestr<<"Omcc_Days_Short_OI_value:"<<MbrClntCntrMmryObj->Omcc_Days_Short_OI_value<<", ";
        filestr<<"Omcc_Shrt_Optn_Min_Chrg:"<<MbrClntCntrMmryObj->Omcc_Shrt_Optn_Min_Chrg<<", ";
        filestr<<"Omcc_Adhc_Margin:"<<MbrClntCntrMmryObj->Omcc_Adhc_Margin<<", ";
		filestr<<"Omcc_Pre_Expiry_Margin:"<<MbrClntCntrMmryObj->Omcc_Pre_Expiry_Margin<<", ";
        filestr<<"Omcc_Net_Dlt_Cntr:"<<MbrClntCntrMmryObj->Omcc_Net_Dlt_Cntr<<", ";
        filestr<<"Omcc_Peep_Net_Dlt_Cntr:"<<MbrClntCntrMmryObj->Omcc_Peep_Net_Dlt_Cntr<<", ";
        filestr<<"Omcc_NSpread_Pos:"<<MbrClntCntrMmryObj->Omcc_NSpread_Pos<<", ";
        filestr<<"Omcc_Adjst_Pos:"<<MbrClntCntrMmryObj->Omcc_Adjst_Pos<<", ";
        filestr<<"Omcc_Weight:"<<MbrClntCntrMmryObj->Omcc_Weight<<", ";
        filestr<<"Omcc_Alrt_Prctn_Sent:"<<MbrClntCntrMmryObj->Omcc_Alrt_Prctn_Sent<<", ";
        filestr<<"Omcc_Undrctnl_Mrgn:"<<MbrClntCntrMmryObj->Omcc_Undrctnl_Mrgn<<", ";
        filestr<<"Omcc_Conc_Mrgn:"<<MbrClntCntrMmryObj->Omcc_Conc_Mrgn<<", ";
        filestr<<"Omcc_Pre_Exp_Epi:"<<MbrClntCntrMmryObj->Omcc_Pre_Exp_Epi;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 8 times in multimap so Net Total Size:"<<MapSize*8;

    filestr.close();
    return SUCCESS;
}

int MultiMapMngr :: Write_UsrClntCntrMstr(string File)
{

    int  count   = 0;
    long MapSize = 0;
    long KeySize = 0;
    long ValSize = 0;
    string key;

    MultiMapIterator ObjMultiMapIterator;
    ofstream filestr;

	struct StUsrClntCntr *stUsrClntCntrobj = NULL;

    filestr.open(File.c_str(),fstream::trunc);
    if (!filestr.is_open())
    {
        cout << "File open failure"<<endl;
        return FAIL;
    }

    for (ObjMultiMapIterator = ObjMultiMap.begin(); ObjMultiMapIterator != ObjMultiMap.end(); ObjMultiMapIterator++)
    {

        count++;
        key = (*ObjMultiMapIterator).first;

        stUsrClntCntrobj= (struct StUsrClntCntr*)(*ObjMultiMapIterator).second;

        filestr<<"Oucc_Cmbr_Id:"<<stUsrClntCntrobj->Oucc_Cmbr_Id<<", ";
        filestr<<"Oucc_Tmbr_Id:"<<stUsrClntCntrobj->Oucc_Tmbr_Id<<", ";
        filestr<<"Oucc_Tusr_Id:"<<stUsrClntCntrobj->Oucc_Tusr_Id<<", ";
        filestr<<"Oucc_Clnt_Id:"<<stUsrClntCntrobj->Oucc_Clnt_Id<<", ";
        filestr<<"Oucc_Pro_Cli_Flg:"<<stUsrClntCntrobj->Oucc_Pro_Cli_Flg<<", ";
        filestr<<"Oucc_Tokn_Nm:"<<stUsrClntCntrobj->Oucc_Tokn_Nm<<", ";
        filestr<<"Oucc_Undrlng_Tokn_Nm:"<<stUsrClntCntrobj->Oucc_Undrlng_Tokn_Nm<<", ";
        filestr<<"Oucc_Mnth_Id:"<<stUsrClntCntrobj->Oucc_Mnth_Id<<", ";
        filestr<<"Oucc_Smbl:"<<stUsrClntCntrobj->Oucc_Smbl<<", ";
        filestr<<"Oucc_Spread_Pos:"<<stUsrClntCntrobj->Oucc_Spread_Pos<<", ";
        filestr<<"Oucc_NSpread_Pos:"<<stUsrClntCntrobj->Oucc_NSpread_Pos<<", ";
        filestr<<"Oucc_Adjst_Pos:"<<stUsrClntCntrobj->Oucc_Adjst_Pos<<", ";
        filestr<<"Oucc_Oi:"<<stUsrClntCntrobj->Oucc_Oi<<", ";
        filestr<<"Oucc_Oi_Value:"<<stUsrClntCntrobj->Oucc_Oi_Value<<", ";
        filestr<<"Oucc_Adhc_Margin:"<<stUsrClntCntrobj->Oucc_Adhc_Margin<<", ";
        filestr<<"Oucc_Undrctnl_Mrgn:"<<stUsrClntCntrobj->Oucc_Undrctnl_Mrgn<<", ";
        filestr<<"Oucc_Post_Adjstmnt_Long_Qty:"<<stUsrClntCntrobj->Oucc_Post_Adjstmnt_Long_Qty<<", ";
        filestr<<"Oucc_Post_Adjstmnt_Long_Value:"<<stUsrClntCntrobj->Oucc_Post_Adjstmnt_Long_Value<<", ";
        filestr<<"Oucc_Post_Adjstmnt_Shrt_Qty:"<<stUsrClntCntrobj->Oucc_Post_Adjstmnt_Shrt_Qty<<", ";
        filestr<<"Oucc_Post_Adjstmnt_Shrt_Value:"<<stUsrClntCntrobj->Oucc_Post_Adjstmnt_Shrt_Value<<", ";
        filestr<<"Oucc_Brght_Frwrd_Long_Qty:"<<stUsrClntCntrobj->Oucc_Brght_Frwrd_Long_Qty<<", ";
        filestr<<"Oucc_Brght_Frwrd_Long_Value:"<<stUsrClntCntrobj->Oucc_Brght_Frwrd_Long_Value<<", ";
        filestr<<"Oucc_Brght_Frwrd_Shrt_Qty:"<<stUsrClntCntrobj->Oucc_Brght_Frwrd_Shrt_Qty<<", ";
        filestr<<"Oucc_Brght_Frwrd_Shrt_Value:"<<stUsrClntCntrobj->Oucc_Brght_Frwrd_Shrt_Value<<", ";
        filestr<<"Oucc_Days_Buy_Qty:"<<stUsrClntCntrobj->Oucc_Days_Buy_Qty<<", ";
        filestr<<"Oucc_Days_Sell_Qty:"<<stUsrClntCntrobj->Oucc_Days_Sell_Qty<<", ";
        filestr<<"Oucc_Days_Buy_Value:"<<stUsrClntCntrobj->Oucc_Days_Buy_Value<<", ";
        filestr<<"Oucc_Days_Sell_Value:"<<stUsrClntCntrobj->Oucc_Days_Sell_Value<<", ";
        filestr<<"Oucc_Prms_Buy_Qty:"<<stUsrClntCntrobj->Oucc_Prms_Buy_Qty<<", ";
        filestr<<"Oucc_Prms_Sell_Qty:"<<stUsrClntCntrobj->Oucc_Prms_Sell_Qty<<", ";
        filestr<<"Oucc_Mtm_Pl:"<<stUsrClntCntrobj->Oucc_Mtm_Pl<<", ";
        filestr<<"Oucc_Shrt_Optn_Min_Chrg:"<<stUsrClntCntrobj->Oucc_Shrt_Optn_Min_Chrg<<", ";
        filestr<<"Oucc_Net_Dlt_Cntr:"<<stUsrClntCntrobj->Oucc_Net_Dlt_Cntr<<", ";
        filestr<<"Oucc_Peep_Net_Dlt_Cntr:"<<stUsrClntCntrobj->Oucc_Peep_Net_Dlt_Cntr<<", ";
        filestr<<"Oucc_Exp_Dt:"<<stUsrClntCntrobj->Oucc_Exp_Dt<<", ";
        filestr<<"Oucc_Pre_Exp_Epi:"<<stUsrClntCntrobj->Oucc_Pre_Exp_Epi<<", ";
        filestr<<"Oucc_Weight:"<<stUsrClntCntrobj->Oucc_Weight;
		filestr<<"Oucc_Pre_Expiry_Margin:"<<stUsrClntCntrobj->Oucc_Pre_Expiry_Margin;
        filestr<<endl;

    }

    KeySize = count * (key.size());
    ValSize = count * (sizeof(StClrMbrMstr));
    MapSize = KeySize + ValSize;

    filestr<<endl<<"No of Rec is:"<<count<<endl;
    filestr<<"Multimap Size with size function is:"<<ObjMultiMap.size()<<endl;
    filestr<<"Total Map Size is:"<<MapSize<<endl;
    filestr<<"Same structure filled 5 times in multimap so Net Total Size:"<<MapSize*5;

    filestr.close();
    return SUCCESS;
}
//CR06531 : Bhoopesh :Start
int MultiMapMngr :: DeleteElementsForMbrClnt(string strTMID,string clientID)
{
	MultiMapIterator ObjMultiMapIterator;
	ObjMultiMapIterator = ObjMultiMap.begin();
	string MapStr,strTM_Id;
	struct StMbrClntMstr*	   _objStMbrClntMstr;

	while(ObjMultiMapIterator != ObjMultiMap.end())
	{
		MapStr = (*ObjMultiMapIterator).first;
		_objStMbrClntMstr = (struct StMbrClntMstr*)(*ObjMultiMapIterator).second;

		//cout<<"Map Str : "<<MapStr.c_str()<<endl;
		//strTM_Id = MapStr.substr( MapStr.find_first_of(":",0));
		cout<<"Inside DeleteElementsForMbrClnt"<<endl;
		cout<<"strTM_Id : "<<strTMID.c_str()<<endl;
		cout<<"Before client_Id : "<<_objStMbrClntMstr->Omcm_Clnt_Id<<endl;
		
		string ClntId = _objStMbrClntMstr->Omcm_Clnt_Id;
		cout<<"After client_Id : "<<ClntId.c_str()<<endl;
		
		if(MapStr == strTMID && ClntId == clientID)
		{
			ObjMultiMap.erase(ObjMultiMapIterator++);
		}
		else
			ObjMultiMapIterator++;
	}
	return(SUCCESS);
}
//CR06531 : Bhoopesh :End
/************************************* End Of Program ***********************************/
