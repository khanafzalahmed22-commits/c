/***************************************************************************
* FILE NAME		: MultiMapMngr.h
*
* CREATION DATE	: 30-DEC-2004
*
* COPYRIGHTS	: Tata Consultancy Services, Mumbai
*
* CREATED BY	: Sonia Joshi
*
* DESCRIPTION	:
*
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   CR. NO   Modification Date   Modification Details	 Remarks
* 1.
****************************************************************************/

#ifndef MAPMNGR
#define MAPMNGR

#include <iostream>
#include <map>
#include <OPMS_DEF.h>
#include <Logger.h>
#include <MAX_LEN.h>
#include <Struct_Mbr_Clnt_Cntr.h>
#include <Struct_Mbr_Clnt_Undrlng_Tier.h>
#include <Struct_Usr_Clnt_Undrlng_Tier.h>
#include <Struct_Cntr.h>
#include <vector>
#include <Struct_Mbr_Clnt_Mstr.h> //CR06531 :Bhoopesh
using namespace std;

typedef multimap <string,void*> MultiMap;
typedef MultiMap :: value_type MultiMapPair;
typedef MultiMap :: iterator MultiMapIterator;

typedef map <string,void*> Map;
typedef Map :: value_type MapPair;
typedef Map :: iterator MapIterator;

typedef	vector <void*> Vector;
typedef Vector :: iterator VectorIterator;

struct stSmblPairDtls
{
    string  sSmbl1;
    string  sSmbl2;
    int     iSmblNmrtr;
    int     iSmblDnrtr;
    double  dCreditPercent;
};

class MultiMapMngr
{
private:

	MultiMap ObjMultiMap;
	Logger *Objlogger;
	int TotRecs;

public:

	MultiMapMngr( Logger *logger )
	{
		ObjMultiMap.clear();
		Objlogger	=	logger;
		TotRecs		=	0;
	};

	~MultiMapMngr()
	{
		ObjMultiMap.clear(); //CR05772 :Bhoopesh 
		ObjMultiMap.~MultiMap();
	};

	int GetTotRecs();


	int Clear();
	MultiMapIterator   GetStartPtr();
	int	PushItem(void* ActLoc,string MultiMapKey);
	void* SearchItem(string MultiMapKey);
	int GetIterator_NoOfRecs(string, int&, MultiMapIterator&);
	int Get_MapItr_NoOfRecs(string , int&, MapIterator&);
	int Get_MMapItr_NoOfRecs(string , int&, MultiMapIterator&);//This function is to access Inner Multimap
	int ClntSmblPushItem(void*, string, string);
	int SortedPushItem(void*, string, string);//This function is to create Multimap of Map
	int SortedPushItem(void*, string, string,Logger*);//This function is to create Multimap of MultiMap
	int Get_Equal_Range(string MultiMapKey, MultiMapIterator& Itr1, MultiMapIterator& Itr2);
	int DeleteElements(string TMID);
	int DeleteElementsForMbrClnt(string strTMID,string clientID); //CR06531 :Bhoopesh
	int DeleteSortedMapElements(string);
	int DeleteSortedMultiMapElements(string);
	
	//Vijay : BMS
	int DeleteSortedMultiMapElementsBMS(string key);
	int DeleteElementsBMS(string key);

//Vijay Start : Move map to file
	int WriteMapInFileAtEOD(int);
	int WriteMapInFile(int);
	int Write_ClrMbrMstr(string);
	int Write_HedgeClntDtls(string);
	int Write_UndrLngTier(string);
	int Write_LegPriority(string);
	int Write_TrdMbrMstr(string);
	int Write_UsrMstr(string);
	int Write_UsrCntrMstr(string);
	int Write_UndrLngMstr(string);
	int Write_CntrMstr(string);
	int Write_ClrMbrCntrMstr(string);
	int Write_MbrClntMstr(string);
	int Write_MbrClntUndrLngTier(string);
	int Write_UsrClntUndrLngTier(string);
	int Write_UsrClntMstr(string);
	int Write_ExpContractMstr(string);
	int Write_UsrClntUndrLngMstr(string);
	int Write_TrdMbrUndrLngMstr(string);
	int Write_ClrMbrUndrLngMstr(string);
	int Write_TrdMbrCntrMstr(string);
	int Write_MbrClntUndrLngMstr(string);
	int Write_MbrClntCntrMstr(string);
	int Write_UsrClntCntrMstr(string);
//Vijay End : Move map to files

};

#endif
