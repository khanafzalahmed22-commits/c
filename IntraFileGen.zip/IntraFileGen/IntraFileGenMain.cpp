/***************************************************************************
* FILE NAME     : IntraFileGenMain.cpp
*
* CREATION DATE : 17-JUN-2011
*
* COPYRIGHTS    : 
*
* CREATED BY    : Vijay Patel	  
*
* DESCRIPTION   :   
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr   	CR. NO   Modification Date	Modification Details   	Remarks
*
***************************************************************************/

#include <iostream>
#include "IntraFileGen.h"
#include <Logger.h>	

int main(int argc, char *argv[])
{

	if ( argc < 4 )
	{
		cerr << "Usage: IntraFileGenMain  <program id> <batch date> <oracle SID> <config file>" << endl ;
		exit(1);
	}
	else
	{
		cout << "****************************************************" << endl ;
		cout << "Program Name: " << argv[0] << endl ;
		cout << "Program ID  : " << argv[1] << endl ;
		cout << "Batch Date  : " << argv[2] << endl ;
		cout << "Oracle SID  : " << argv[3] << endl ;
		cout << "Config file : " << argv[4] << endl ;
		cout << "****************************************************" << endl ;
	}
	
	Logger *logger = new Logger();
	logger->initialize( argv[4] , "LOGGER_PARAMETERS");
	cout<<"Logger initialized successfully in main"<<endl;
	
	cout<<"Starting"<<endl;
	//IntraFileGen* objIntraFileGen = new IntraFileGen(logger);  //CR07214 :Vinod commented
	IntraFileGen* objIntraFileGen = new IntraFileGen(argv[4],logger);   //CR07214 :Vinod Added
	cout<<"Intra File Gen Object created"<<endl;
	//if(objIntraFileGen->InitConfigParameters(argv[4]) !=SUCCESS)     //CR06831:Vinod:Commented
	if(objIntraFileGen->InitConfigParameters(argv[4],argv[2]) !=SUCCESS)  //CR06831:Vinod:Added
	{
		cout<<"Inside InitConfigParameters"<<endl;
	  logger->logMessage(LEVEL_CRITICAL,"Error in InitConfigParameters //%s:%d",__FILE__,__LINE__);
	}
	logger->logMessage(LEVEL_INFORMATIONAL,"Inside IntraFileGenMain :: Main %s:%d",__FILE__,__LINE__);
	
	cout<<"Before Run"<<endl;
	//int ret_val =  objIntraFileGen->Run();  //CR07214 :Vinod commented
	int ret_val =  objIntraFileGen->Run(argv[2]);  //CR07214 :Vinod Added

	if(ret_val == FAIL)
	{
		 logger->logMessage(LEVEL_CRITICAL,"Error in Run() exiting process with ret_val %d",ret_val);
		delete objIntraFileGen;
		exit(1);
	}

	logger->logMessage(LEVEL_INFORMATIONAL,"Exiting Application IntraFileGenMain %s:%d",__FILE__,__LINE__);
	delete objIntraFileGen;
	return (0);
}
