/***************************************************************************
* FILE NAME		: IntraFileGen.h
* CREATION DATE	: 17-JUN-2011 
* COPYRIGHTS	: 
* CREATED BY	: Vijay Patel
* DESCRIPTION	: 
* MODIFICATION COMMENTS:
* --------------------------------------------------------------------------
* Sr CR. NO	Modification Date	Modification Details	 Remarks 
*
*  1.  CR02387		07-MAR-2013			Automation of DLYMGN file.	ANM/AD
*  2.  CR02415		06-06-2014          CLIOI report generation on      ABHISHEK         
										Underlying,Near Month Commodity  
*										and Commodity Level
***************************************************************************/
#ifndef IntraFileGen_H
#define IntraFileGen_H

//#include <pqxx/pqxx>	//CR07206 : 24-July-24 Mahesh //CR07206:Vinod Commented for Oracle
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <sqlca.h>
#include "DEF.h"
#include <fstream>
#include <iostream>
#include <dirent.h>
#include <ConfigurationFileManager.h>
#include <Logger.h>
#include <DBCommunication.h>
#include <OPMS_DEF.h>
#include <sstream>
#include <Struct_Cntr.h>
#include <Struct_Mbr_Clnt_Cntr.h>
#include <Struct_Mbr_Clnt_Mstr.h>
#include <MultiMapMngr.h>
#include <GtwyGlobals.h> //CR:02387 ANM/AD added
#include<map>
#include <Struct_Mbr_Clnt_Undrlng.h>	//CR02415:Abhi added
#include <Struct_UndrLngMst.h>			//CR02415:Abhi added
#include <Struct_Mbr_Clnt_Comm.h>		//CR02415:Abhi added
#include <Struct_Comm_Mstr.h>			//CR02415:Abhi added 
#include <Struct_Comm_Smbl.h>			//CR02415:Abhi added            
#include <Struct_Usr_Clnt_Cntr.h>		//CR06386 : Sumaiya
#include <Struct_Mbr_Mstr.h>			//CR06386 : Sumaiya
#include <Struct_Clr_Mbr_Mstr.h>		//CR06831 : Bharat Added
#include <Struct_Clnt_Cp_Mstr.h>		//CR06831 : Bharat Added
#include <vector>						//CR06831 : Annapoorna : Added
#include "QueryBuilder.h" 				//CR06831 : Annapoorna : Added
#include "DBScriptExecution.h"
// #include "Generate_New_TM_Mrgn.h"       //CR07214 :Vinod :Added     
// #include "Generate_New_CM_Mrgn.h"       //CR07214 :Vinod :Added

#define IP_ADDR_LEN     16

using namespace std;
//using namespace pqxx;	//CR07206 : 24-July-24 Mahesh   //CR07206:Vinod Commented for Oracle

class IntraFileGen
{
public:
	//IntraFileGen(Logger*);  //CR07214 :Vinod commented
	IntraFileGen(char *confFile,Logger*); //CR07214 :Vinod Added
	~IntraFileGen();

	//int InitConfigParameters(char* cfgFileName);   //CR06831:Vinod:Commented
	int InitConfigParameters(char* cfgFileName,char* batch_date);  //CR06831:Vinod:added
	int SocketTest(char* final, int *Flag);
	//int WriteIntoFile(
	//int Run(); //CR07214 :Vinod commented
	int Run(char *BatchDate);
	//int GenerateReport(); //CR:02387 ANM/AD commented
	//int GenerateReport(char filetype); //CR:02387 ANM/AD added //CR07728 :Vinod Commented
	int GenerateReport(char filetype,char exec_rep_flag); //CR07728 : Vinod Added
	int Generate_Transcode(char*, string);
	int GetTM(char* final);
	int Write_File_Margin(int);
	int Write_File_OI(int);
	int	Create_File_Name(string&, string);
	int	Create_File_Name(string&, string, char*); //Added for CR06521 by MSS
	int Get_Batch_Date();
	int Read_Trigger_Timings();
	int MoveFile(char); //CR:02387 ANM/AD added char parameter 
	int FtpFile(char); //CR:02387 ANM/AD added char parameter
	int RunCpCodePythonProcess();
	int RunClientPortalProcess();

	//CR06784 : Rahul  Start
	int Receive_Socket_Data(int,string&);
	int SendTranscodeData(char*,int,char*,int&);
	int GetFilename(string,string&,char);
	int GetBMSOutFile(string&);
	int Receive_BMS_Socket_Data(int,string&);
	int Read_File_Count(char Flag); //CR06831 Bharat Added
	//CR06784 : Rahul  End
	int CheckDBScript(string Directory,char* m_connection_str); //CR06831:Vinod Added
	// CR04477:PHASE-4:Vivek:DATE:07-Jul-2016: File copy path
	/* Commented  by MSS for FT06500 START
	int		CopyDLYMGNFileToNas();
	 Commented  by MSS for FT06500 STOP */
	// CR04477:PHASE-4:Vivek:DATE:07-Jul-2016: End		
	
private:
	Logger *logger;
	DbComm	*ObjDbComm;		
	ConfigurationFileManager *ObjConfigurationFileManager;
	int m_ServerPORT;
	char m_ServerIP[IP_ADDR_LEN];
	string sSource_Path;
	string sRpstry_Path;
	string sFile_Name;
	int TimeOut;
	int m_Buffer_Time;
	char *rBuffer; //CR:02387 ANM/AD added
	/*Commented  by MSS for FT06500 START
	int m_Buffer_Time_Dlymgn; //CR:02387 ANM/AD added 
	int DlymgnIndex;
	Commented  by MSS for FT06500 END*/
	string m_ServerIpAddr;
	string m_Username;
	string m_Password;
	string m_Port;			//CR06359: Arushi added
	string m_DestPath;
	string m_CCSS_Path;
	string m_Mode;         //CR06713: Bharat Added
	/*Commented  by MSS for FT06500 START
	string m_DlyMgnFileName; //CR:02387 ANM/AD added 
	string m_DlyMgnFile;     //CR:02387 ANM/AD added 
	string m_DestPathDlyMgn; //CR:02387 ANM/AD added
	string m_DlyServerIpAddr;
	string m_DlyUsername;
	string m_DlyPassword;
	string m_DlyPort;		//CR06359: Arushi added
	string m_DlyCCSS_Path;
	Commented  by MSS for FT06500 START*/
	//CR06386 : Sumaiya : start
	string m_PSNServerIpAddr;
	string m_PSNUsername;
	string m_PSNPassword;
	string m_PSNPort;
	string m_PSNDestPath;
	string m_PSNRepoPath;
	string m_PSNFile;
	//CR06386 : Sumaiya : end
	FILE	*seq_fp; //CR06521 
	
	//CR06351 : Bhoopesh :Start
	string m_CpCodeBinaryName;
	string m_CPCodeConfigName;
	string m_CpCodeBinaryPath;
	string m_CpCodeConfigPath;
	//CR06351 : Bhoopesh : End
	//CR06784: Start
	int m_BMS_Port;
	string m_BMS_Path;
	int m_Retry_Count;
	
	//CR06784: End
// DDD : CR01713 : 20 - Apr - 2012 - Start		
	int m_PollFreq;
	int socketfd; //ANM added
	int	m_PollIntSec;
	//ujjwal : FTR02038 : 17-july-2012 :: For Resending the Transcode to the gateway.
	int m_TransResendIntSec; 
	//ujjwal : FTR02038 : 17-july-2012 :: For Resending the Transcode to the gateway.
	int m_MaxNodes;
	string m_DBMode;	//CR07206 : 08-Aug-24 Mahesh
	string m_MapFilePath;
	string m_MapCliFilePath; //remove Hardcode path for map repository added by MSS
	string m_MapPeakFilePath; //remove Hardcode path for map repository added by MSS
	string m_CntrMstrFileName;
	string m_MbrClntCntrFileName;
	string m_MbrClntFileName;
	
	string m_UndrlngMstrFileName;		//CR02415: Abhi added
	string m_MbrClntUndrlngFileName;	//CR02415: Abhi added
	string m_CommMstrFileName;			//CR02415: Abhi added
	string m_MbrClntCommFileName;		//CR02415: Abhi added   
	string m_CommSmblFileName;			//CR02415: Abhi added   
	string m_UsrClntCntrFileName;		//CR06386 : Sumaiya : Added
	string m_MbrMstrFileName;			//CR06386 : Sumaiya : Added
	string m_ClrMbrMstrFileName;		//CR06831 : Bharat : Added
	
	string m_SrchCntrMstrFileName;
	string m_SrchMbrClntCntrFileName;
	string m_SrchMbrClntFileName;	
	
	string m_SrchUndrlngMstrFileName;		//CR02415: Abhi added
	string m_SrchMbrClntUndrlngFileName;	//CR02415: Abhi added
	string m_SrchCommMstrFileName;			//CR02415: Abhi added
	string m_SrchMbrClntCommFileName;		//CR02415: Abhi added     
	string m_SrchCommSmblFileName;			//CR02415: Abhi added   
	string m_SrchUsrClntCntrFileName;		//CR06386 : Sumaiya : Added
	string m_SrchMbrMstrFileName;			//CR06386 : Sumaiya : Added
	string m_SrchClrMbrMstrFileName;		//CR06831 : Bharat : Added
	string m_IntraFileGenPath;				//CR06831 : Bharat :  Added
	string m_contractMasterTxt;				//CR07206 : 02-Aug-24 Mahesh
	string m_undrlyingMasterTxt;			//CR07206 : 02-Aug-24 Mahesh
	string m_IntraFileGenName;				//CR06831 : Bharat :  Added
	string m_CpCodeFileName;				//CR06831 : Bharat : Added 
	
	string m_SqroffFilePath;                //CR06831 : Vinod : Added
	string m_SqroffFileName;                //CR06831 : Vinod : Added

	//CR07206 : 24-July-24 Mahesh Start
	string m_ClrMbrMstrTxtFileName;
	string m_TrdMbrMstrTxtFileName;
	string m_CntrMstrTxtFileName;
	string m_MbrClntMstrTxtFilename;
	string m_MbrClntCntrMstrTxtFileName;
	string m_UndrLyingMstrTxtFileName;
	//CR07206 : 24-July-24 Mahesh End

	//string m_DBscriptFilePath;              //CR06831 : Vinod : Added
	string m_DBscriptFileName;              //CR06831 : Vinod : Added
	string m_DBscriptDestPath;              //CR06831 : Vinod : Added
	string m_DBscriptErrorPath;	
	// char* m_Conn_Str;   					//CR06831 : Vinod : Added
	string m_PeakFileName;             //CR06831 : Vinod : Added 
	string m_PSNFileName;              //CR06831 : Vinod : Added
	
	MultiMapMngr	*ObjCntrMultiMapMngr;
	MultiMapMngr	*ObjMbrClntCntrMultiMapMngr;
	MultiMapMngr	*ObjMbrClntMultiMapMngr;
	
	//MultiMapMngr	*ObjMbrClntPeakMultiMapMngr; //CR05351 : Bhoopesh :Added
		
	MultiMapMngr	*ObjUndrlngMultiMapMngr;		//CR02415: Abhi added  
	MultiMapMngr	*ObjMbrClntUndrlngMultiMapMngr;	//CR02415: Abhi added
	MultiMapMngr	*ObjCommMultiMapMngr;			//CR02415: Abhi added
	MultiMapMngr	*ObjMbrClntCommMultiMapMngr;	//CR02415: Abhi added    
	MultiMapMngr	*ObjCommSmblMultiMapMngr;		//CR02415: Abhi added        
	MultiMapMngr	*ObjUsrClntCntrMultiMapMngr;	//CR06386 : Sumaiya : Added
	MultiMapMngr	*ObjMbrMstrMultipMapMngr;		//CR06386 : Sumaiya : Added
	MultiMapMngr	*ObjMbrMstrMultipMapMngrPeak;	//CR06831 : Bharat : Added
	MultiMapMngr    *ObjClrMbrMstrMultipMapMngrPeak;//CR06831 : Bharat : Added
	MultiMapMngr    *ObjClntCPCodeMultipMapMngrPeak;//CR06831 : Bharat : Added 
	string ins_str;                                 //CR06831 : Vinod : Added

	DBScriptExecution *objDBScriptExe; 	         //CR06831 : Vinod : Added
	MultiMapMngr 	*ObjMbrClientMultiMapBMS;			//CR06784 : Pritpal : added : 
	// Generate_New_TM_Mrgn        *ObjGenerate_New_TM_Mrgn;  //CR07214:Vinod Added
	// Generate_New_CM_Mrgn        *ObjGenerate_New_CM_Mrgn;  //CR07214:Vinod Added
	// CR04477:PHASE-4:Vivek:DATE:07-Jul-2016: File copy path
	char* 	m_Nas_path; 
	// CR04477:PHASE-4:Vivek:DATE:07-Jul-2016: End
    //char BATCH_DATE[MAX_DATE_LEN + 1];
    ofstream snap_outfile;
    string 		szConfigFile ;   //CR07214: Vinod Added
    //CR07206 : Vinod : Start
    string m_POSTGRESServerIpAddr;
	string m_POSTGRESUsername;
	string m_POSTGRESPassword;
	string m_POSTGRESPort;
	string m_POSTGRESDbname;
	string m_OracleUser;
	string m_OraclePassword;
	string m_SourceDB;
	string m_DestDB;
	int m_Index_Count;
	int m_FTP_Index_Count;
	int m_BMS_Out_Count;
	string m_BMS_Name;
	string Dpnd_Path;
	string m_BackupDestPath;
	char* FileType;
	string File_Type;
	//CR07206 : Vinod : End

	//CR07206 : 24-July-24 Mahesh Start
	string m_ClrMbrMstr;
	string m_TrdMbrMstr;
	string m_CntrMstr;
	string m_MbrClntMstr;
	string m_MbrClntCntrMstr;
	string m_UndrLyingMstr;
	//CR07206 : 24-July-24 Mahesh End



private:
	//int SendTranscodeToGtwy(); //CR:02387 ANM/AD commented
	//int SendTranscodeToGtwy(char,char* out_file = NULL); //CR:02387 ANM/AD added //CR07206:Vinod:Commented
	int SendTranscodeToGtwy(char); //CR:02387 ANM/AD added
	int SendTranscodeToBMS(char,char* out_file = NULL); //CR07206:Vinod Added
	//int CheckAndCreateMapFiles();//CR:02387 ANM/AD commented
	int CheckAndCreateMapFiles(char); //CR:02387 ANM/AD added
	int CheckAndCreateMapFilesForPSN(char); //CR06386 : Sumaiya : Added
	/*Commented  by MSS for FT06500 START
	int CheckDlyMgnReport(char);//CR:02387 ANM/AD added
	int CreateDlyMgnReport();//CR:02387 ANM/AD Commented  by MSS for FT06500*/
	int CreateReports();
	///Commented  by MSS for FT06500 int UpdateDlyMgnCount();//CR:02387 ANM/AD added
	
	int CreateContractMasterMap(string &MapFilePath);
	int CreateMbrClntCntrMstrMap(string &MapFilePath);
	int CreateMbrClntMstrMap(string &MapFilePath);
	int CreateUndrlngMasterMap(string &MapFilePath);		//CR02415: Abhi added  
	int CreateMbrClntUndrlngMstrMap(string &MapFilePath);	//CR02415: Abhi added  
	int CreateCommodityMasterMap(string &MapFilePath);		//CR02415: Abhi added  
	int CreateMbrClntCommMstrMap(string &MapFilePath);		//CR02415: Abhi added  
	int CreateCommSmblMstrMap(string &MapFilePath);			//CR02415: Abhi added         
	int CreateUsrClntCntrMstrMap(string &MapFilePath);		//CR06386 : Sumaiya
	int CreateMbrMstrMap(string &MapFilePath);				//CR06386 : Sumaiya
	int CreateMbrMstrMapPeak(string &MapFilePath);			//CR06831 : Bharat Added
	int CreateClrMbrMstrMapPeak(string &MapFilePath);		//CR06831 : Bharat Added
	
	int CreateClrMbrMstrMapPeakFromTxt(string &MapFilePath);	//CR07206 : 24-July-24 Mahesh	
	int CreateMbrMstrMapPeakFromTxt(string &MapFilePath);	//CR07206 : 24-July-24 Mahesh
	int CreateCntrMstrMapPeakFromTxt(string &MapFilePath);	//CR07206 : 24-July-24 Mahesh
	int CreateMbrClntMstrMapPeakFromTxt(string &MapFilePath);	//CR07206 : 24-July-24 Mahesh
	int CreateMbrClntCntrMstrMapPeakFromTxt(string &MapFilePath);	//CR07206 : 24-July-24 Mahesh
	int CreateUndrLyingMstrMapPeakFromTxt(string &MapFilePath);	//CR07206 : 24-July-24 Mahesh

	int CreateCpCodeMapPeak(string &MapFilePath);			//CR06831 : Bharat Added
	
	int Write_File_Margin(string &TMId);
	int Write_File_OI(string &szTmId);
	int CreatePSNReport(); //CR06386 : Sumaiya : Added
	//CR06461 : MSS Start
	int UpdateExcutePeakTime();
	//int CreateMarginReports(); //CR07728 :Vinod Commented
	int CreateMarginReports(char); //CR07728 :Vinod Added
	int	Write_File_PeakMargin(string &TMId, double& TMSpanMargStr, double &TMNBPStr, double &TMInitMrgnStr,double &ELMrgnStr, double &TMPreExpMrgnStr, double &TMDlvryMrgnStr, double &TMUndrctMrgnStr, double &TMConcMrgnStr, double &TMAdhocMrgnStr, double &TMCashMrgnStr, double &TMCrystLossMrgnStr, double &TMMTMStr,char *szPeak_Number, char *szSnap_Timing,double &TM_Coll_Value,double &TM_Short_Allocation);
	int UpdatePeakFlag();
	int UpdatePeakMargin(char*, char*, char*, int ,double, double,double,double); //CR06759 : Rahul Added
	//CR06461: MSS Added End
	int	MoveMapFile(char);//Fixed for BUGID 30965
	int CreateMapFilesForPeakwithCP(string exc_time); //CR06351 :Bhoopesh :Added
	struct StMbrClntMstr* GetMbrClntRecord(string tm, string client); //CR06351 :Bhoopesh :Added
// DDD : CR01713 : 20 - Apr - 2012 - End		
	int ReadFileUpdateMap(char*); 	//CR06784 : added : 
	int ClearMultiMap(MultiMapMngr*);		//CR06784 : Pritpal : added : 
	//int CheckDBScript(string Directory,char* m_connection_str);
	int CheckCPMultiMap(MultiMapMngr*);
	//void ClearDBScript(string filename);

	//CR07206 : 24-July-24 Mahesh Start
	//int fetchDataFromPostGres();   //CR07206:Vinod Commented for Oracle
	int fetchDataFromOracleDB();
	
	//int writeFromPostGreToTxt(string&, connection&,string&);  //CR07206:Vinod Commented for Oracle
	int createMapFromTxt();

	//int createClrMbrMstrTxtFromPG(connection&,string&);   //CR07206:Vinod Commented for Oracle
	int createClrMbrMstrTxtFromODB(string&);

	//int createTrdMbrMstrTxtFromPG(connection&,string&);    //CR07206:Vinod Commented for Oracle
	int createTrdMbrMstrTxtFromODB(string&);

	//int createCntrMstrTxtFromPG(connection&,string&);     //CR07206:Vinod Commented for Oracle
	int createCntrMstrTxtFromODB(string&);

	//int createMbrClntMstrTxtFromPG(connection&,string&);   //CR07206:Vinod Commented for Oracle
	int createMbrClntMstrTxtFromODB(string&);

	//int createMbrClntCntrTxtFromPG(connection&,string&);    //CR07206:Vinod Commented for Oracle
	int createMbrClntCntrTxtFromODB(string&);

	//int createUndrLyingMstrTxtFromPG(connection&,string&);      //CR07206:Vinod Commented for Oracle
	int createUndrLyingMstrTxtFromODB(string&);

	//CR07206 : 24-July-24 Mahesh End
	int Generate_DpndFile();  //CR07728:Vinod Added
	int process_trigger(char*);

//FTR02145 :ANANYA :DATE :08-OCT-2012 :START.
public:
	int m_ThrdSleepTime;
	bool	m_DBInUse;
	Logger * GetloggerObjct()
	{
		return	logger;
	}
//FTR02145 :ANANYA :DATE :08-OCT-2012 :END.
//FTR02220 :ANANYA :DATE :19-OCT-2012 :START :For exiting the thread before exiting the process.
public:
	bool m_ThrdStts;
//FTR02220 :ANANYA :DATE :19-OCT-2012 :END :For exiting the thread before exiting the process.
} ;

#endif

/*********** End of Header File **************/
